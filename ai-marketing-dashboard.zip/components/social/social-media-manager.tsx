"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Facebook,
  Instagram,
  Twitter,
  Linkedin,
  Calendar,
  ImageIcon,
  Video,
  Hash,
  Heart,
  MessageCircle,
  Share,
  TrendingUp,
  Clock,
  Send,
  Plus,
  Zap,
  RefreshCw,
} from "lucide-react"
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const socialPlatforms = [
  { id: "facebook", name: "Facebook", icon: Facebook, color: "#1877F2", connected: true },
  { id: "instagram", name: "Instagram", icon: Instagram, color: "#E4405F", connected: true },
  { id: "twitter", name: "Twitter", icon: Twitter, color: "#1DA1F2", connected: false },
  { id: "linkedin", name: "LinkedIn", icon: Linkedin, color: "#0A66C2", connected: true },
]

const engagementData = [
  { month: "Jan", likes: 1200, comments: 340, shares: 180, reach: 15000 },
  { month: "Feb", likes: 1450, comments: 420, shares: 220, reach: 18500 },
  { month: "Mar", likes: 1680, comments: 380, shares: 280, reach: 22000 },
  { month: "Apr", likes: 1920, comments: 510, shares: 340, reach: 26500 },
  { month: "May", likes: 2100, comments: 580, shares: 390, reach: 29000 },
  { month: "Jun", likes: 2350, comments: 640, shares: 450, reach: 32500 },
]

const platformPerformance = [
  { platform: "Instagram", followers: 12500, engagement: 4.2, posts: 45 },
  { platform: "Facebook", followers: 8900, engagement: 3.1, posts: 32 },
  { platform: "LinkedIn", followers: 3200, engagement: 5.8, posts: 18 },
  { platform: "Twitter", followers: 0, engagement: 0, posts: 0 },
]

const scheduledPosts = [
  {
    id: 1,
    platform: "instagram",
    content: "Excited to share our latest product update! 🚀 #innovation #tech",
    scheduledFor: "Today, 2:00 PM",
    status: "scheduled",
    engagement: { likes: 0, comments: 0, shares: 0 },
  },
  {
    id: 2,
    platform: "facebook",
    content: "Join us for our upcoming webinar on digital marketing trends...",
    scheduledFor: "Tomorrow, 10:00 AM",
    status: "scheduled",
    engagement: { likes: 0, comments: 0, shares: 0 },
  },
  {
    id: 3,
    platform: "linkedin",
    content: "Thrilled to announce our partnership with industry leaders...",
    scheduledFor: "Yesterday, 9:00 AM",
    status: "published",
    engagement: { likes: 24, comments: 8, shares: 12 },
  },
]

const trendingHashtags = [
  { tag: "#digitalmarketing", posts: 2.1, trend: "up" },
  { tag: "#socialmedia", posts: 1.8, trend: "up" },
  { tag: "#contentcreator", posts: 1.5, trend: "down" },
  { tag: "#marketing", posts: 3.2, trend: "up" },
  { tag: "#branding", posts: 0.9, trend: "stable" },
]

export function SocialMediaManager() {
  const [selectedPlatform, setSelectedPlatform] = useState("instagram")
  const [postContent, setPostContent] = useState("")
  const [scheduledTime, setScheduledTime] = useState("")

  const getPlatformIcon = (platformId: string) => {
    const platform = socialPlatforms.find((p) => p.id === platformId)
    if (!platform) return Facebook
    return platform.icon
  }

  const getPlatformColor = (platformId: string) => {
    const platform = socialPlatforms.find((p) => p.id === platformId)
    return platform?.color || "#666"
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Social Media Management</h2>
          <p className="text-muted-foreground">Manage and schedule your social media posts across platforms</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Sync All
          </Button>
          <Button size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Create Post
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {platformPerformance.map((platform, index) => {
          const Icon = getPlatformIcon(platform.platform.toLowerCase())
          return (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">{platform.platform}</CardTitle>
                <Icon className="h-4 w-4" style={{ color: getPlatformColor(platform.platform.toLowerCase()) }} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{platform.followers.toLocaleString()}</div>
                <div className="flex items-center justify-between text-xs mt-2">
                  <span className="text-muted-foreground">Engagement: {platform.engagement}%</span>
                  <span className="text-muted-foreground">{platform.posts} posts</span>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Tabs defaultValue="composer" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="composer">Composer</TabsTrigger>
          <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="engagement">Engagement</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="composer" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Create New Post</CardTitle>
                <CardDescription>Compose and schedule your social media content</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="platform">Platform</Label>
                  <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {socialPlatforms
                        .filter((p) => p.connected)
                        .map((platform) => {
                          const Icon = platform.icon
                          return (
                            <SelectItem key={platform.id} value={platform.id}>
                              <div className="flex items-center gap-2">
                                <Icon className="h-4 w-4" style={{ color: platform.color }} />
                                {platform.name}
                              </div>
                            </SelectItem>
                          )
                        })}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="content">Post Content</Label>
                  <Textarea
                    id="content"
                    placeholder="What's on your mind?"
                    value={postContent}
                    onChange={(e) => setPostContent(e.target.value)}
                    className="min-h-[120px]"
                  />
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{postContent.length}/280 characters</span>
                    <Button variant="ghost" size="sm">
                      <Zap className="h-4 w-4 mr-1" />
                      AI Enhance
                    </Button>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <ImageIcon className="h-4 w-4 mr-2" />
                    Add Image
                  </Button>
                  <Button variant="outline" size="sm">
                    <Video className="h-4 w-4 mr-2" />
                    Add Video
                  </Button>
                  <Button variant="outline" size="sm">
                    <Hash className="h-4 w-4 mr-2" />
                    Hashtags
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="schedule">Schedule</Label>
                  <div className="flex gap-2">
                    <Input
                      type="datetime-local"
                      value={scheduledTime}
                      onChange={(e) => setScheduledTime(e.target.value)}
                    />
                    <Button variant="outline">
                      <Calendar className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button className="flex-1">
                    <Send className="h-4 w-4 mr-2" />
                    Post Now
                  </Button>
                  <Button variant="outline" className="flex-1 bg-transparent">
                    <Clock className="h-4 w-4 mr-2" />
                    Schedule
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Content Suggestions</CardTitle>
                <CardDescription>AI-powered content ideas and trending topics</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <h4 className="text-sm font-medium">Trending Hashtags</h4>
                  <div className="space-y-2">
                    {trendingHashtags.map((hashtag, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 border border-border rounded-lg"
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium">{hashtag.tag}</span>
                          <Badge variant="outline" className="text-xs">
                            {hashtag.posts}M posts
                          </Badge>
                        </div>
                        <div className="flex items-center gap-1">
                          {hashtag.trend === "up" && <TrendingUp className="h-3 w-3 text-green-500" />}
                          {hashtag.trend === "down" && <TrendingUp className="h-3 w-3 text-red-500 rotate-180" />}
                          {hashtag.trend === "stable" && <div className="h-3 w-3 bg-gray-400 rounded-full" />}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="text-sm font-medium">Content Ideas</h4>
                  <div className="space-y-2">
                    {[
                      "Share behind-the-scenes content",
                      "Post customer testimonials",
                      "Create educational carousel posts",
                      "Share industry insights",
                    ].map((idea, index) => (
                      <div key={index} className="p-2 border border-border rounded-lg">
                        <p className="text-sm">{idea}</p>
                        <Button variant="ghost" size="sm" className="mt-1 h-6 text-xs">
                          Use This Idea
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="scheduled" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Scheduled Posts</CardTitle>
              <CardDescription>Manage your upcoming and published posts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {scheduledPosts.map((post) => {
                  const Icon = getPlatformIcon(post.platform)
                  return (
                    <div key={post.id} className="flex items-start gap-4 p-4 border border-border rounded-lg">
                      <div className="p-2 rounded-full bg-muted">
                        <Icon className="h-4 w-4" style={{ color: getPlatformColor(post.platform) }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium mb-1">{post.content}</p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground mb-2">
                          <span>{post.scheduledFor}</span>
                          <Badge variant={post.status === "published" ? "default" : "secondary"}>{post.status}</Badge>
                        </div>
                        {post.status === "published" && (
                          <div className="flex items-center gap-4 text-xs">
                            <div className="flex items-center gap-1">
                              <Heart className="h-3 w-3" />
                              <span>{post.engagement.likes}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <MessageCircle className="h-3 w-3" />
                              <span>{post.engagement.comments}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Share className="h-3 w-3" />
                              <span>{post.engagement.shares}</span>
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                        <Button variant="ghost" size="sm">
                          Delete
                        </Button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Engagement Trends</CardTitle>
                <CardDescription>Monthly engagement metrics across platforms</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={engagementData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="likes"
                      stackId="1"
                      stroke="hsl(var(--chart-1))"
                      fill="hsl(var(--chart-1))"
                      fillOpacity={0.6}
                    />
                    <Area
                      type="monotone"
                      dataKey="comments"
                      stackId="1"
                      stroke="hsl(var(--chart-2))"
                      fill="hsl(var(--chart-2))"
                      fillOpacity={0.6}
                    />
                    <Area
                      type="monotone"
                      dataKey="shares"
                      stackId="1"
                      stroke="hsl(var(--chart-3))"
                      fill="hsl(var(--chart-3))"
                      fillOpacity={0.6}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Platform Comparison</CardTitle>
                <CardDescription>Follower growth and engagement by platform</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={platformPerformance.filter((p) => p.followers > 0)}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="platform" className="text-xs" />
                    <YAxis className="text-xs" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Bar dataKey="followers" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Total Reach</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">32.5K</div>
                <p className="text-xs text-green-500">+12% this month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Engagement Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">4.2%</div>
                <p className="text-xs text-green-500">+0.8% vs last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Posts This Month</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">95</div>
                <p className="text-xs text-muted-foreground">Across all platforms</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="engagement" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Interactions</CardTitle>
              <CardDescription>Latest comments, mentions, and messages</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    platform: "instagram",
                    user: "@sarah_marketing",
                    action: "commented",
                    content: "Love this content! Very helpful tips 👍",
                    time: "2 hours ago",
                    post: "Digital Marketing Guide",
                  },
                  {
                    platform: "facebook",
                    user: "John Smith",
                    action: "shared",
                    content: "Great insights on social media strategy",
                    time: "4 hours ago",
                    post: "Social Media Best Practices",
                  },
                  {
                    platform: "linkedin",
                    user: "Marketing Pro",
                    action: "mentioned",
                    content: "Thanks for the valuable content @yourcompany",
                    time: "1 day ago",
                    post: "Industry Trends 2024",
                  },
                ].map((interaction, index) => {
                  const Icon = getPlatformIcon(interaction.platform)
                  return (
                    <div key={index} className="flex items-start gap-4 p-3 border border-border rounded-lg">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback>
                          <Icon className="h-4 w-4" style={{ color: getPlatformColor(interaction.platform) }} />
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium">{interaction.user}</span>
                          <span className="text-xs text-muted-foreground">{interaction.action}</span>
                          <span className="text-xs text-muted-foreground">•</span>
                          <span className="text-xs text-muted-foreground">{interaction.time}</span>
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">{interaction.content}</p>
                        <p className="text-xs text-muted-foreground">on "{interaction.post}"</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm">
                          Reply
                        </Button>
                        <Button variant="ghost" size="sm">
                          Like
                        </Button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Connected Platforms</CardTitle>
              <CardDescription>Manage your social media account connections</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {socialPlatforms.map((platform) => {
                  const Icon = platform.icon
                  return (
                    <div
                      key={platform.id}
                      className="flex items-center justify-between p-3 border border-border rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <Icon className="h-5 w-5" style={{ color: platform.color }} />
                        <div>
                          <p className="font-medium">{platform.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {platform.connected ? "Connected" : "Not connected"}
                          </p>
                        </div>
                      </div>
                      <Button variant={platform.connected ? "outline" : "default"} size="sm">
                        {platform.connected ? "Disconnect" : "Connect"}
                      </Button>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Posting Preferences</CardTitle>
              <CardDescription>Configure your default posting settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Default Posting Time</Label>
                <Select defaultValue="optimal">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="optimal">Optimal Time (AI-suggested)</SelectItem>
                    <SelectItem value="morning">Morning (9:00 AM)</SelectItem>
                    <SelectItem value="afternoon">Afternoon (2:00 PM)</SelectItem>
                    <SelectItem value="evening">Evening (6:00 PM)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Auto-hashtag Suggestions</Label>
                <Select defaultValue="enabled">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="enabled">Enabled</SelectItem>
                    <SelectItem value="disabled">Disabled</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Content Approval</Label>
                <Select defaultValue="manual">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manual">Manual Approval Required</SelectItem>
                    <SelectItem value="auto">Auto-publish Scheduled Posts</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
