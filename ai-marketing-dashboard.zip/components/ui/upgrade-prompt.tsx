import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Crown, Zap, Shield } from "lucide-react"

interface UpgradePromptProps {
  feature: string
  planRequired: "premium" | "super"
  message?: string
  className?: string
}

export function UpgradePrompt({ feature, planRequired, message, className }: UpgradePromptProps) {
  const planDetails = {
    premium: {
      icon: Crown,
      color: "bg-gradient-to-r from-orange-500 to-amber-500",
      textColor: "text-orange-600",
      bgColor: "bg-orange-50 dark:bg-orange-950/20",
      borderColor: "border-orange-200 dark:border-orange-800",
    },
    super: {
      icon: Shield,
      color: "bg-gradient-to-r from-purple-500 to-pink-500",
      textColor: "text-purple-600",
      bgColor: "bg-purple-50 dark:bg-purple-950/20",
      borderColor: "border-purple-200 dark:border-purple-800",
    },
  }

  const plan = planDetails[planRequired]
  const Icon = plan.icon

  return (
    <Card className={`${plan.bgColor} ${plan.borderColor} ${className}`}>
      <CardHeader className="text-center pb-4">
        <div className={`${plan.color} rounded-full p-3 w-fit mx-auto mb-2`}>
          <Icon className="h-6 w-6 text-white" />
        </div>
        <CardTitle className={`text-lg ${plan.textColor}`}>
          {planRequired === "premium" ? "Premium Feature" : "Super User Feature"}
        </CardTitle>
        <CardDescription>
          {message || `Upgrade to ${planRequired === "premium" ? "Premium" : "Super User"} to access ${feature}`}
        </CardDescription>
      </CardHeader>
      <CardContent className="text-center">
        <div className="space-y-3">
          <Badge variant="secondary" className={`${plan.textColor} ${plan.bgColor}`}>
            <Zap className="h-3 w-3 mr-1" />
            {planRequired === "premium" ? "Premium Plan Required" : "Super User Access Required"}
          </Badge>
          <Button className={`w-full ${plan.color} text-white hover:opacity-90`}>
            Upgrade to {planRequired === "premium" ? "Premium" : "Super User"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
