"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import {
  CheckCircle,
  Circle,
  Key,
  Globe,
  Mail,
  Share2,
  BarChart3,
  Users,
  Settings,
  AlertCircle,
  ExternalLink,
  Copy,
  Eye,
  EyeOff,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface OnboardingStep {
  id: string
  title: string
  description: string
  completed: boolean
  required: boolean
}

interface APIIntegration {
  id: string
  name: string
  description: string
  icon: React.ReactNode
  status: "connected" | "pending" | "error"
  required: boolean
  fields: {
    name: string
    label: string
    type: "text" | "password" | "url"
    placeholder: string
    required: boolean
  }[]
}

export function ClientOnboarding() {
  const { toast } = useToast()
  const [currentStep, setCurrentStep] = useState(0)
  const [showTokens, setShowTokens] = useState<Record<string, boolean>>({})
  const [formData, setFormData] = useState<Record<string, any>>({})

  const onboardingSteps: OnboardingStep[] = [
    {
      id: "business-info",
      title: "Business Information",
      description: "Tell us about your business and marketing goals",
      completed: false,
      required: true,
    },
    {
      id: "api-integrations",
      title: "API Integrations",
      description: "Connect your marketing tools and platforms",
      completed: false,
      required: true,
    },
    {
      id: "campaign-setup",
      title: "Initial Campaign Setup",
      description: "Configure your first marketing campaigns",
      completed: false,
      required: false,
    },
    {
      id: "team-setup",
      title: "Team & Permissions",
      description: "Invite team members and set permissions",
      completed: false,
      required: false,
    },
  ]

  const apiIntegrations: APIIntegration[] = [
    {
      id: "google-ads",
      name: "Google Ads",
      description: "Connect Google Ads for PPC campaign management",
      icon: <Globe className="h-5 w-5" />,
      status: "pending",
      required: true,
      fields: [
        {
          name: "clientId",
          label: "Client ID",
          type: "text",
          placeholder: "Enter Google Ads Client ID",
          required: true,
        },
        {
          name: "clientSecret",
          label: "Client Secret",
          type: "password",
          placeholder: "Enter Client Secret",
          required: true,
        },
        {
          name: "refreshToken",
          label: "Refresh Token",
          type: "password",
          placeholder: "Enter Refresh Token",
          required: true,
        },
      ],
    },
    {
      id: "facebook-ads",
      name: "Facebook Ads",
      description: "Connect Facebook Ads Manager for social advertising",
      icon: <Share2 className="h-5 w-5" />,
      status: "pending",
      required: true,
      fields: [
        {
          name: "accessToken",
          label: "Access Token",
          type: "password",
          placeholder: "Enter Facebook Access Token",
          required: true,
        },
        {
          name: "adAccountId",
          label: "Ad Account ID",
          type: "text",
          placeholder: "Enter Ad Account ID",
          required: true,
        },
      ],
    },
    {
      id: "google-analytics",
      name: "Google Analytics",
      description: "Connect Google Analytics for website tracking",
      icon: <BarChart3 className="h-5 w-5" />,
      status: "pending",
      required: true,
      fields: [
        {
          name: "trackingId",
          label: "Tracking ID",
          type: "text",
          placeholder: "UA-XXXXXXXXX-X or G-XXXXXXXXXX",
          required: true,
        },
        {
          name: "serviceAccountKey",
          label: "Service Account Key",
          type: "password",
          placeholder: "Paste JSON service account key",
          required: true,
        },
      ],
    },
    {
      id: "mailchimp",
      name: "Mailchimp",
      description: "Connect Mailchimp for email marketing automation",
      icon: <Mail className="h-5 w-5" />,
      status: "pending",
      required: false,
      fields: [
        { name: "apiKey", label: "API Key", type: "password", placeholder: "Enter Mailchimp API Key", required: true },
        { name: "serverPrefix", label: "Server Prefix", type: "text", placeholder: "us1, us2, etc.", required: true },
      ],
    },
    {
      id: "hubspot",
      name: "HubSpot",
      description: "Connect HubSpot CRM for lead management",
      icon: <Users className="h-5 w-5" />,
      status: "pending",
      required: false,
      fields: [
        { name: "apiKey", label: "API Key", type: "password", placeholder: "Enter HubSpot API Key", required: true },
        { name: "portalId", label: "Portal ID", type: "text", placeholder: "Enter Portal ID", required: true },
      ],
    },
  ]

  const handleInputChange = (integrationId: string, fieldName: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [integrationId]: {
        ...prev[integrationId],
        [fieldName]: value,
      },
    }))
  }

  const toggleTokenVisibility = (key: string) => {
    setShowTokens((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  const testConnection = async (integrationId: string) => {
    // Simulate API connection test
    toast({
      title: "Testing Connection",
      description: "Validating API credentials...",
    })

    // Simulate async operation
    setTimeout(() => {
      toast({
        title: "Connection Successful",
        description: `${apiIntegrations.find((i) => i.id === integrationId)?.name} connected successfully!`,
      })
    }, 2000)
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied to clipboard",
      description: "API key copied successfully",
    })
  }

  const renderBusinessInfo = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="businessName">Business Name *</Label>
          <Input
            id="businessName"
            placeholder="Enter your business name"
            value={formData.businessName || ""}
            onChange={(e) => setFormData((prev) => ({ ...prev, businessName: e.target.value }))}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="industry">Industry *</Label>
          <Input
            id="industry"
            placeholder="e.g., E-commerce, SaaS, Healthcare"
            value={formData.industry || ""}
            onChange={(e) => setFormData((prev) => ({ ...prev, industry: e.target.value }))}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="website">Website URL *</Label>
          <Input
            id="website"
            type="url"
            placeholder="https://yourwebsite.com"
            value={formData.website || ""}
            onChange={(e) => setFormData((prev) => ({ ...prev, website: e.target.value }))}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="monthlyBudget">Monthly Marketing Budget</Label>
          <Input
            id="monthlyBudget"
            type="number"
            placeholder="5000"
            value={formData.monthlyBudget || ""}
            onChange={(e) => setFormData((prev) => ({ ...prev, monthlyBudget: e.target.value }))}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="goals">Marketing Goals *</Label>
        <Textarea
          id="goals"
          placeholder="Describe your primary marketing objectives (e.g., increase leads by 50%, improve brand awareness, boost online sales)"
          value={formData.goals || ""}
          onChange={(e) => setFormData((prev) => ({ ...prev, goals: e.target.value }))}
          rows={4}
        />
      </div>

      <div className="space-y-4">
        <Label>Target Audience</Label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label htmlFor="ageRange">Age Range</Label>
            <Input
              id="ageRange"
              placeholder="25-45"
              value={formData.ageRange || ""}
              onChange={(e) => setFormData((prev) => ({ ...prev, ageRange: e.target.value }))}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="location">Primary Location</Label>
            <Input
              id="location"
              placeholder="United States, Europe, etc."
              value={formData.location || ""}
              onChange={(e) => setFormData((prev) => ({ ...prev, location: e.target.value }))}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="interests">Key Interests</Label>
            <Input
              id="interests"
              placeholder="Technology, Fashion, Health"
              value={formData.interests || ""}
              onChange={(e) => setFormData((prev) => ({ ...prev, interests: e.target.value }))}
            />
          </div>
        </div>
      </div>
    </div>
  )

  const renderAPIIntegrations = () => (
    <div className="space-y-6">
      <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-blue-600 dark:text-blue-400 mt-0.5" />
          <div>
            <h4 className="font-medium text-blue-900 dark:text-blue-100">Secure Token Storage</h4>
            <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
              All API keys and tokens are encrypted and stored securely. We never share your credentials with third
              parties.
            </p>
          </div>
        </div>
      </div>

      <div className="grid gap-6">
        {apiIntegrations.map((integration) => (
          <Card key={integration.id} className="relative">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg text-primary">{integration.icon}</div>
                  <div>
                    <CardTitle className="text-lg">{integration.name}</CardTitle>
                    <CardDescription>{integration.description}</CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {integration.required && (
                    <Badge variant="destructive" className="text-xs">
                      Required
                    </Badge>
                  )}
                  <Badge variant={integration.status === "connected" ? "default" : "secondary"} className="text-xs">
                    {integration.status === "connected" ? "Connected" : "Not Connected"}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                {integration.fields.map((field) => (
                  <div key={field.name} className="space-y-2">
                    <Label htmlFor={`${integration.id}-${field.name}`}>
                      {field.label} {field.required && "*"}
                    </Label>
                    <div className="relative">
                      <Input
                        id={`${integration.id}-${field.name}`}
                        type={
                          field.type === "password" && !showTokens[`${integration.id}-${field.name}`]
                            ? "password"
                            : "text"
                        }
                        placeholder={field.placeholder}
                        value={formData[integration.id]?.[field.name] || ""}
                        onChange={(e) => handleInputChange(integration.id, field.name, e.target.value)}
                        className={field.type === "password" ? "pr-20" : ""}
                      />
                      {field.type === "password" && (
                        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => toggleTokenVisibility(`${integration.id}-${field.name}`)}
                          >
                            {showTokens[`${integration.id}-${field.name}`] ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                          </Button>
                          {formData[integration.id]?.[field.name] && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0"
                              onClick={() => copyToClipboard(formData[integration.id][field.name])}
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between pt-4 border-t">
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <ExternalLink className="h-4 w-4" />
                  Setup Guide
                </Button>
                <Button
                  onClick={() => testConnection(integration.id)}
                  disabled={!formData[integration.id] || Object.keys(formData[integration.id]).length === 0}
                  className="gap-2"
                >
                  <Key className="h-4 w-4" />
                  Test Connection
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )

  const renderCampaignSetup = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Quick Campaign Setup</CardTitle>
          <CardDescription>
            Let our AI create your first marketing campaigns based on your business information
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="seo-campaign">SEO Content Campaign</Label>
                <Switch id="seo-campaign" defaultChecked />
              </div>
              <p className="text-sm text-muted-foreground">Generate SEO-optimized blog posts and landing pages</p>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="social-campaign">Social Media Campaign</Label>
                <Switch id="social-campaign" defaultChecked />
              </div>
              <p className="text-sm text-muted-foreground">Create and schedule social media content across platforms</p>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="email-campaign">Email Marketing Campaign</Label>
                <Switch id="email-campaign" />
              </div>
              <p className="text-sm text-muted-foreground">Set up automated email sequences for lead nurturing</p>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="ppc-campaign">PPC Advertising Campaign</Label>
                <Switch id="ppc-campaign" />
              </div>
              <p className="text-sm text-muted-foreground">Launch targeted Google and Facebook ad campaigns</p>
            </div>
          </div>

          <div className="pt-4 border-t">
            <Button className="w-full gap-2">
              <Settings className="h-4 w-4" />
              Generate AI Campaign Strategy
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderTeamSetup = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Team Members</CardTitle>
          <CardDescription>Invite team members and set their permissions</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <Input placeholder="Enter email address" className="flex-1" />
            <Button>Send Invite</Button>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <p className="font-medium">john@company.com</p>
                <p className="text-sm text-muted-foreground">Admin</p>
              </div>
              <Badge variant="outline">Pending</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const completedSteps = onboardingSteps.filter((step) => step.completed).length
  const progress = (completedSteps / onboardingSteps.length) * 100

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-foreground">Client Onboarding</h2>
          <p className="text-muted-foreground mt-1">Set up your marketing automation in just a few steps</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-sm text-muted-foreground">
            {completedSteps} of {onboardingSteps.length} completed
          </div>
          <div className="w-32">
            <Progress value={progress} className="h-2" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="space-y-2">
          {onboardingSteps.map((step, index) => (
            <div
              key={step.id}
              className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors ${
                currentStep === index ? "bg-primary/10 border border-primary/20" : "hover:bg-muted/50"
              }`}
              onClick={() => setCurrentStep(index)}
            >
              <div className="flex-shrink-0">
                {step.completed ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <Circle className="h-5 w-5 text-muted-foreground" />
                )}
              </div>
              <div className="min-w-0">
                <p className={`text-sm font-medium ${currentStep === index ? "text-primary" : ""}`}>{step.title}</p>
                <p className="text-xs text-muted-foreground truncate">{step.description}</p>
              </div>
              {step.required && (
                <Badge variant="outline" className="text-xs ml-auto">
                  Required
                </Badge>
              )}
            </div>
          ))}
        </div>

        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <CardTitle>{onboardingSteps[currentStep]?.title}</CardTitle>
              <CardDescription>{onboardingSteps[currentStep]?.description}</CardDescription>
            </CardHeader>
            <CardContent>
              {currentStep === 0 && renderBusinessInfo()}
              {currentStep === 1 && renderAPIIntegrations()}
              {currentStep === 2 && renderCampaignSetup()}
              {currentStep === 3 && renderTeamSetup()}
            </CardContent>
          </Card>

          <div className="flex justify-between mt-6">
            <Button
              variant="outline"
              onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
              disabled={currentStep === 0}
            >
              Previous
            </Button>
            <Button
              onClick={() => setCurrentStep(Math.min(onboardingSteps.length - 1, currentStep + 1))}
              disabled={currentStep === onboardingSteps.length - 1}
            >
              {currentStep === onboardingSteps.length - 1 ? "Complete Setup" : "Next"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
