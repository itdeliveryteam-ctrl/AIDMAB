"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import {
  TrendingUp,
  TrendingDown,
  Search,
  Target,
  Eye,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Clock,
  Users,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
} from "lucide-react"
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const organicTrafficData = [
  { month: "Jan", traffic: 12500, keywords: 245, rankings: 78 },
  { month: "Feb", traffic: 15200, keywords: 267, rankings: 82 },
  { month: "Mar", traffic: 18900, keywords: 289, rankings: 85 },
  { month: "Apr", traffic: 22100, keywords: 312, rankings: 88 },
  { month: "May", traffic: 26800, keywords: 334, rankings: 91 },
  { month: "Jun", traffic: 31500, keywords: 356, rankings: 94 },
]

const semPerformanceData = [
  { month: "Jan", spend: 2500, clicks: 1250, conversions: 45, cpc: 2.0 },
  { month: "Feb", spend: 2800, clicks: 1420, conversions: 52, cpc: 1.97 },
  { month: "Mar", spend: 3200, clicks: 1680, conversions: 61, cpc: 1.9 },
  { month: "Apr", spend: 3600, clicks: 1950, conversions: 73, cpc: 1.85 },
  { month: "May", spend: 4100, clicks: 2280, conversions: 89, cpc: 1.8 },
  { month: "Jun", spend: 4500, clicks: 2600, conversions: 104, cpc: 1.73 },
]

const keywordData = [
  { keyword: "digital marketing", position: 3, volume: 12000, difficulty: 78, traffic: 2400 },
  { keyword: "SEO services", position: 7, volume: 8500, difficulty: 65, traffic: 1200 },
  { keyword: "content marketing", position: 12, volume: 15000, difficulty: 82, traffic: 800 },
  { keyword: "social media marketing", position: 5, volume: 9800, difficulty: 71, traffic: 1800 },
  { keyword: "email marketing", position: 2, volume: 6700, difficulty: 58, traffic: 2800 },
]

const competitorData = [
  { name: "Competitor A", visibility: 85, keywords: 1250, traffic: 45000 },
  { name: "Competitor B", visibility: 72, keywords: 980, traffic: 32000 },
  { name: "Your Site", visibility: 68, keywords: 856, traffic: 28500 },
  { name: "Competitor C", visibility: 61, keywords: 720, traffic: 22000 },
]

const technicalSeoIssues = [
  { type: "Critical", count: 3, color: "hsl(var(--destructive))" },
  { type: "Warning", count: 12, color: "hsl(var(--chart-4))" },
  { type: "Notice", count: 28, color: "hsl(var(--chart-2))" },
]

export function SEOSEMDashboard() {
  const [timeRange, setTimeRange] = useState("6m")
  const [selectedMetric, setSelectedMetric] = useState("traffic")

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">SEO/SEM Analytics</h2>
          <p className="text-muted-foreground">Track your search engine optimization and marketing performance</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1m">Last Month</SelectItem>
              <SelectItem value="3m">Last 3 Months</SelectItem>
              <SelectItem value="6m">Last 6 Months</SelectItem>
              <SelectItem value="1y">Last Year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Organic Traffic</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">31,500</div>
            <div className="flex items-center gap-1 text-xs">
              <ArrowUpRight className="h-3 w-3 text-green-500" />
              <span className="text-green-500">+17.5% from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Keyword Rankings</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">356</div>
            <div className="flex items-center gap-1 text-xs">
              <ArrowUpRight className="h-3 w-3 text-green-500" />
              <span className="text-green-500">+22 new rankings</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Ad Spend</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$4,500</div>
            <div className="flex items-center gap-1 text-xs">
              <ArrowUpRight className="h-3 w-3 text-red-500" />
              <span className="text-red-500">+9.8% from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">ROAS</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.2x</div>
            <div className="flex items-center gap-1 text-xs">
              <ArrowUpRight className="h-3 w-3 text-green-500" />
              <span className="text-green-500">+0.3x from last month</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="keywords">Keywords</TabsTrigger>
          <TabsTrigger value="competitors">Competitors</TabsTrigger>
          <TabsTrigger value="technical">Technical SEO</TabsTrigger>
          <TabsTrigger value="campaigns">SEM Campaigns</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Organic Traffic Trend</CardTitle>
                <CardDescription>Monthly organic search traffic and keyword rankings</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={organicTrafficData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="traffic"
                      stroke="hsl(var(--primary))"
                      fill="hsl(var(--primary))"
                      fillOpacity={0.1}
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>SEM Performance</CardTitle>
                <CardDescription>Paid search campaign metrics and ROI</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={semPerformanceData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="conversions"
                      stroke="hsl(var(--chart-2))"
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--chart-2))" }}
                    />
                    <Line
                      type="monotone"
                      dataKey="clicks"
                      stroke="hsl(var(--chart-3))"
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--chart-3))" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>SEO Health Score</CardTitle>
                <CardDescription>Overall website optimization score</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-4xl font-bold text-primary mb-2">87</div>
                  <p className="text-sm text-muted-foreground">Out of 100</p>
                </div>
                <Progress value={87} className="h-3" />
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Technical SEO</span>
                    <span className="text-green-500">92%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Content Quality</span>
                    <span className="text-green-500">85%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>User Experience</span>
                    <span className="text-yellow-500">78%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Performing Pages</CardTitle>
                <CardDescription>Pages driving the most organic traffic</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { page: "/blog/seo-guide", traffic: 4200, change: 12 },
                  { page: "/services/digital-marketing", traffic: 3800, change: 8 },
                  { page: "/blog/content-strategy", traffic: 2900, change: -3 },
                  { page: "/about", traffic: 2100, change: 15 },
                ].map((page, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{page.page}</p>
                      <p className="text-xs text-muted-foreground">{page.traffic} visitors</p>
                    </div>
                    <div className="flex items-center gap-1">
                      {page.change > 0 ? (
                        <ArrowUpRight className="h-3 w-3 text-green-500" />
                      ) : (
                        <ArrowDownRight className="h-3 w-3 text-red-500" />
                      )}
                      <span className={`text-xs ${page.change > 0 ? "text-green-500" : "text-red-500"}`}>
                        {Math.abs(page.change)}%
                      </span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent SEO Issues</CardTitle>
                <CardDescription>Latest technical and content issues found</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { type: "Critical", issue: "Missing meta descriptions", count: 3 },
                  { type: "Warning", issue: "Slow loading pages", count: 7 },
                  { type: "Notice", issue: "Missing alt text", count: 15 },
                  { type: "Fixed", issue: "Broken internal links", count: 2 },
                ].map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {item.type === "Critical" && <AlertTriangle className="h-4 w-4 text-red-500" />}
                      {item.type === "Warning" && <Clock className="h-4 w-4 text-yellow-500" />}
                      {item.type === "Notice" && <Eye className="h-4 w-4 text-blue-500" />}
                      {item.type === "Fixed" && <CheckCircle className="h-4 w-4 text-green-500" />}
                      <span className="text-sm">{item.issue}</span>
                    </div>
                    <Badge variant="outline">{item.count}</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="keywords" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Keyword Performance</h3>
            <div className="flex items-center gap-2">
              <Input placeholder="Search keywords..." className="w-64" />
              <Button variant="outline">
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="border-b border-border">
                    <tr className="text-left">
                      <th className="p-4 font-medium">Keyword</th>
                      <th className="p-4 font-medium">Position</th>
                      <th className="p-4 font-medium">Search Volume</th>
                      <th className="p-4 font-medium">Difficulty</th>
                      <th className="p-4 font-medium">Traffic</th>
                      <th className="p-4 font-medium">Trend</th>
                    </tr>
                  </thead>
                  <tbody>
                    {keywordData.map((keyword, index) => (
                      <tr key={index} className="border-b border-border hover:bg-muted/50">
                        <td className="p-4 font-medium">{keyword.keyword}</td>
                        <td className="p-4">
                          <Badge
                            variant={
                              keyword.position <= 3 ? "default" : keyword.position <= 10 ? "secondary" : "outline"
                            }
                          >
                            #{keyword.position}
                          </Badge>
                        </td>
                        <td className="p-4 text-muted-foreground">{keyword.volume.toLocaleString()}</td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <Progress value={keyword.difficulty} className="h-2 w-16" />
                            <span className="text-xs">{keyword.difficulty}%</span>
                          </div>
                        </td>
                        <td className="p-4 text-muted-foreground">{keyword.traffic.toLocaleString()}</td>
                        <td className="p-4">
                          {Math.random() > 0.5 ? (
                            <TrendingUp className="h-4 w-4 text-green-500" />
                          ) : (
                            <TrendingDown className="h-4 w-4 text-red-500" />
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="competitors" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Competitor Analysis</CardTitle>
              <CardDescription>Compare your SEO performance with competitors</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={competitorData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="name" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                  <Bar dataKey="visibility" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {competitorData.map((competitor, index) => (
              <Card key={index} className={competitor.name === "Your Site" ? "ring-2 ring-primary" : ""}>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">{competitor.name}</CardTitle>
                  {competitor.name === "Your Site" && (
                    <Badge variant="default" className="w-fit">
                      You
                    </Badge>
                  )}
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Visibility</span>
                    <span className="font-medium">{competitor.visibility}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Keywords</span>
                    <span className="font-medium">{competitor.keywords.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Est. Traffic</span>
                    <span className="font-medium">{competitor.traffic.toLocaleString()}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="technical" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Technical Issues Overview</CardTitle>
                <CardDescription>Distribution of SEO issues by severity</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie
                      data={technicalSeoIssues}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="count"
                    >
                      {technicalSeoIssues.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                <div className="grid grid-cols-3 gap-4 mt-4">
                  {technicalSeoIssues.map((issue, index) => (
                    <div key={index} className="text-center">
                      <div className="w-3 h-3 rounded-full mx-auto mb-1" style={{ backgroundColor: issue.color }} />
                      <p className="text-xs font-medium">{issue.type}</p>
                      <p className="text-xs text-muted-foreground">{issue.count} issues</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Site Performance</CardTitle>
                <CardDescription>Core Web Vitals and performance metrics</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Largest Contentful Paint</span>
                    <span className="text-green-500">1.2s</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>First Input Delay</span>
                    <span className="text-green-500">45ms</span>
                  </div>
                  <Progress value={92} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Cumulative Layout Shift</span>
                    <span className="text-yellow-500">0.08</span>
                  </div>
                  <Progress value={78} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Mobile Friendliness</span>
                    <span className="text-green-500">98%</span>
                  </div>
                  <Progress value={98} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="campaigns" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Active Campaigns</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">8</div>
                <p className="text-xs text-muted-foreground">2 paused, 1 draft</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Total Impressions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">2.4M</div>
                <p className="text-xs text-green-500">+15% this month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Avg. CPC</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$1.73</div>
                <p className="text-xs text-green-500">-$0.27 vs last month</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Campaign Performance</CardTitle>
              <CardDescription>Monthly spend, clicks, and conversion trends</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={semPerformanceData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="spend"
                    stackId="1"
                    stroke="hsl(var(--chart-1))"
                    fill="hsl(var(--chart-1))"
                    fillOpacity={0.6}
                  />
                  <Area
                    type="monotone"
                    dataKey="conversions"
                    stackId="2"
                    stroke="hsl(var(--chart-2))"
                    fill="hsl(var(--chart-2))"
                    fillOpacity={0.6}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
