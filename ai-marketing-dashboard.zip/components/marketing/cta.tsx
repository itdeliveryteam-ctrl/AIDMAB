"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles, Calendar, Play } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

export function CTA() {
  const [showDemoForm, setShowDemoForm] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    phone: "",
  })

  const handleDemoRequest = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Demo requested:", formData)
    alert("Demo request submitted! We'll contact you within 24 hours.")
    setShowDemoForm(false)
    setFormData({ name: "", email: "", company: "", phone: "" })
  }

  return (
    <section className="py-20 px-4 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10">
      <div className="max-w-4xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 bg-gradient-to-r from-primary/20 to-secondary/20 border border-primary/30 rounded-full px-4 py-2 mb-8">
          <Sparkles className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium">Ready to Transform Your Marketing?</span>
        </div>

        <h2 className="text-4xl md:text-5xl font-bold mb-6">
          Start Your
          <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            {" "}
            AI Journey{" "}
          </span>
          Today
        </h2>

        <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          Join thousands of businesses already using AIDMAB to automate their marketing and achieve unprecedented
          growth.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
          <Button
            size="lg"
            onClick={() => setShowDemoForm(true)}
            className="bg-gradient-to-r from-accent to-secondary hover:opacity-90 text-lg px-8 py-6 shadow-lg hover:shadow-xl transition-all"
          >
            <Play className="w-5 h-5 mr-2" />
            Watch Live Demo
          </Button>
          <Button
            size="lg"
            onClick={() => setShowDemoForm(true)}
            variant="outline"
            className="text-lg px-8 py-6 bg-transparent border-2 border-primary hover:bg-primary/10"
          >
            <Calendar className="w-5 h-5 mr-2" />
            Schedule Personal Demo
          </Button>
          <Link href="/dashboard">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-6">
              Start Free Trial
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>

        {showDemoForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-background rounded-lg p-8 max-w-md w-full shadow-2xl">
              <h3 className="text-2xl font-bold mb-6 text-center">Request Your Demo</h3>
              <form onSubmit={handleDemoRequest} className="space-y-4">
                <input
                  type="text"
                  placeholder="Full Name *"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-primary"
                />
                <input
                  type="email"
                  placeholder="Business Email *"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-primary"
                />
                <input
                  type="text"
                  placeholder="Company Name *"
                  required
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-primary"
                />
                <input
                  type="tel"
                  placeholder="Phone Number"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-primary"
                />
                <div className="flex gap-3 pt-4">
                  <Button type="submit" className="flex-1 bg-gradient-to-r from-primary to-secondary">
                    Request Demo
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setShowDemoForm(false)} className="flex-1">
                    Cancel
                  </Button>
                </div>
              </form>
            </div>
          </div>
        )}

        <p className="text-sm text-muted-foreground mt-6">
          No credit card required • 14-day free trial • Cancel anytime
        </p>
      </div>
    </section>
  )
}
