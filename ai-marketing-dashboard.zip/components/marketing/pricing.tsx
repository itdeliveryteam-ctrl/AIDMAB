import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, Star } from "lucide-react"
import Link from "next/link"

export function Pricing() {
  const plans = [
    {
      name: "Basic",
      price: "$29",
      description: "Perfect for small businesses getting started",
      features: [
        "AI Content Generation (50/month)",
        "Basic SEO Analytics",
        "Social Media Scheduling",
        "Email Support",
        "1 User Account",
      ],
      popular: false,
    },
    {
      name: "Premium",
      price: "$99",
      description: "Ideal for growing businesses and agencies",
      features: [
        "AI Content Generation (500/month)",
        "Advanced SEO/SEM Analytics",
        "Multi-Platform Social Media",
        "CRM Integration",
        "Priority Support",
        "5 User Accounts",
        "Custom Templates",
      ],
      popular: true,
    },
    {
      name: "Super User",
      price: "$299",
      description: "Enterprise solution with unlimited access",
      features: [
        "Unlimited AI Content Generation",
        "Full Analytics Suite",
        "White-label Options",
        "API Access",
        "Dedicated Account Manager",
        "Unlimited Users",
        "Custom Integrations",
        "Advanced Security",
      ],
      popular: false,
    },
  ]

  return (
    <section className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">
            Choose Your
            <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent"> Plan</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Start free and scale as you grow. All plans include our core AI features with different usage limits and
            advanced capabilities.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`relative ${plan.popular ? "border-primary shadow-xl scale-105" : "border-border"}`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-primary to-secondary text-white px-4 py-1 rounded-full text-sm font-medium flex items-center gap-1">
                    <Star className="w-4 h-4" />
                    Most Popular
                  </div>
                </div>
              )}

              <CardHeader className="text-center pb-8">
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground">/month</span>
                </div>
                <CardDescription className="mt-2">{plan.description}</CardDescription>
              </CardHeader>

              <CardContent className="space-y-6">
                <ul className="space-y-3">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center gap-3">
                      <Check className="w-5 h-5 text-primary flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Link href="/dashboard" className="block">
                  <Button
                    className={`w-full ${
                      plan.popular ? "bg-gradient-to-r from-primary to-secondary hover:opacity-90" : ""
                    }`}
                    variant={plan.popular ? "default" : "outline"}
                  >
                    Get Started
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
