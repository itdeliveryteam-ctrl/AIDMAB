import { Bot, BarChart3, Calendar, Users, Zap, Target } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export function Features() {
  const features = [
    {
      icon: Bot,
      title: "AI Content Generation",
      description:
        "Create high-quality blog posts, social media content, and email campaigns with our advanced AI engine.",
      gradient: "from-primary to-secondary",
    },
    {
      icon: BarChart3,
      title: "SEO/SEM Analytics",
      description:
        "Track rankings, monitor competitors, and optimize your search performance with comprehensive analytics.",
      gradient: "from-secondary to-accent",
    },
    {
      icon: Calendar,
      title: "Content Calendar",
      description: "Plan, schedule, and manage all your content across multiple platforms from one unified dashboard.",
      gradient: "from-accent to-primary",
    },
    {
      icon: Users,
      title: "CRM Integration",
      description: "Seamlessly connect with Salesforce, HubSpot, and other CRM platforms to sync your marketing data.",
      gradient: "from-primary to-accent",
    },
    {
      icon: Zap,
      title: "Marketing Automation",
      description: "Automate repetitive tasks and workflows to focus on strategy while AI handles the execution.",
      gradient: "from-secondary to-primary",
    },
    {
      icon: Target,
      title: "Performance Tracking",
      description: "Monitor campaign performance, track ROI, and get actionable insights to improve your marketing.",
      gradient: "from-accent to-secondary",
    },
  ]

  return (
    <section className="py-20 px-4 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">
            Everything You Need to
            <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent"> Scale</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Our comprehensive platform combines AI-powered automation with intuitive design to supercharge your
            marketing efforts.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow group">
              <CardHeader>
                <div
                  className={`w-12 h-12 bg-gradient-to-br ${feature.gradient} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                >
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base leading-relaxed">{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
