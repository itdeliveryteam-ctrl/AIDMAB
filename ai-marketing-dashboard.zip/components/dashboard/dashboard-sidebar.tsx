"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import {
  BarChart3,
  Brain,
  Calendar,
  FileText,
  Home,
  Share2,
  Users,
  Settings,
  Zap,
  Crown,
  Shield,
  Lock,
  Lightbulb,
  Briefcase,
  UserPlus,
} from "lucide-react"
import { useFeatureAccess } from "@/hooks/use-feature-access"

interface User {
  id: string
  email: string
  name: string
  role: "basic" | "premium" | "super"
}

interface DashboardSidebarProps {
  user: User
  activeTab: string
  setActiveTab: (tab: string) => void
  isOpen: boolean
}

export function DashboardSidebar({ user, activeTab, setActiveTab, isOpen }: DashboardSidebarProps) {
  const { checkFeatureAccess } = useFeatureAccess(user.role)

  const navigationItems = [
    { id: "overview", label: "Overview", icon: Home, feature: null },
    { id: "onboarding", label: "Client Onboarding", icon: UserPlus, feature: null },
    { id: "analytics", label: "SEO/SEM Analytics", icon: BarChart3, feature: "seoBasicAnalytics" as const },
    { id: "content", label: "AI Content Gen", icon: Brain, feature: "aiContentGeneration" as const },
    { id: "recommendations", label: "AI Recommendations", icon: Lightbulb, feature: "aiRecommendations" as const },
    { id: "jobs", label: "AI Job Manager", icon: Briefcase, feature: "aiJobManager" as const },
    { id: "social", label: "Social Media", icon: Share2, feature: "socialMediaBasic" as const },
    { id: "calendar", label: "Content Calendar", icon: Calendar, feature: "basicCalendar" as const },
    { id: "crm", label: "CRM Integration", icon: Users, feature: "basicCrm" as const },
    { id: "admin", label: "Admin Panel", icon: Shield, feature: "adminPanel" as const },
    { id: "automation", label: "Automation", icon: Zap, feature: "workflowAutomation" as const },
    { id: "reports", label: "Reports", icon: FileText, feature: null },
  ]

  return (
    <aside
      className={cn(
        "fixed left-0 top-16 h-[calc(100vh-4rem)] bg-sidebar border-r border-sidebar-border transition-all duration-300 z-40",
        isOpen ? "w-64" : "w-16",
      )}
    >
      <nav className="p-4 space-y-2">
        {isOpen && (
          <div className="mb-6 p-3 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 rounded-lg border border-primary/20">
            <div className="flex items-center gap-2 mb-2">
              {user.role === "super" && <Crown className="h-4 w-4 text-accent animate-pulse" />}
              <span className="text-sm font-medium bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                {user.role === "super" ? "Super User" : user.role === "premium" ? "Premium" : "Basic"}
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              {user.role === "super"
                ? "Full access to all features"
                : user.role === "premium"
                  ? "Advanced marketing tools"
                  : "Essential marketing features"}
            </p>
          </div>
        )}

        {navigationItems.map((item) => {
          const Icon = item.icon
          const isActive = activeTab === item.id
          const featureAccess = item.feature
            ? checkFeatureAccess(item.feature)
            : { canAccess: true, requiresUpgrade: false }
          const isLocked = !featureAccess.canAccess

          return (
            <div key={item.id} className="relative">
              <Button
                variant={isActive ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start gap-3 h-10 transition-all duration-200",
                  !isOpen && "justify-center px-2",
                  isActive && "bg-gradient-to-r from-primary to-secondary text-white shadow-lg",
                  !isActive && !isLocked && "hover:bg-gradient-to-r hover:from-primary/10 hover:to-secondary/10",
                  isLocked && "opacity-60 cursor-not-allowed",
                )}
                onClick={() => !isLocked && setActiveTab(item.id)}
                disabled={isLocked}
              >
                <Icon
                  className={cn(
                    "h-5 w-5 flex-shrink-0",
                    isActive ? "text-white" : isLocked ? "text-muted-foreground" : "text-primary",
                  )}
                />
                {isOpen && (
                  <div className="flex items-center justify-between w-full">
                    <span className="truncate">{item.label}</span>
                    <div className="flex items-center gap-1">
                      {isLocked && <Lock className="h-3 w-3 text-muted-foreground" />}
                      {featureAccess.requiresUpgrade && featureAccess.planRequired === "premium" && (
                        <Badge
                          variant="secondary"
                          className="text-xs bg-gradient-to-r from-orange-500/20 to-amber-500/20 text-orange-600"
                        >
                          Pro
                        </Badge>
                      )}
                      {featureAccess.requiresUpgrade && featureAccess.planRequired === "super" && (
                        <Badge
                          variant="default"
                          className="text-xs bg-gradient-to-r from-purple-500/80 to-pink-500/80 text-white"
                        >
                          Super
                        </Badge>
                      )}
                    </div>
                  </div>
                )}
              </Button>
            </div>
          )
        })}

        {isOpen && (
          <div className="pt-4 mt-4 border-t border-sidebar-border">
            <Button
              variant="ghost"
              className="w-full justify-start gap-3 h-10 hover:bg-gradient-to-r hover:from-primary/10 hover:to-secondary/10"
              onClick={() => setActiveTab("settings")}
            >
              <Settings className="h-5 w-5 text-muted-foreground" />
              Settings
            </Button>
          </div>
        )}
      </nav>
    </aside>
  )
}
