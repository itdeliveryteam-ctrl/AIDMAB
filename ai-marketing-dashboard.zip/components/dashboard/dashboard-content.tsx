"use client"

import type React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Users,
  FileText,
  Brain,
  BarChart3,
  Share2,
  Zap,
  ArrowUpRight,
  Clock,
  Target,
  DollarSign,
  Eye,
} from "lucide-react"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { AIContentGenerator } from "@/components/content/ai-content-generator"
import { SEOSEMDashboard } from "@/components/analytics/seo-sem-dashboard"
import { SocialMediaManager } from "@/components/social/social-media-manager"
import { ContentCalendar } from "@/components/calendar/content-calendar"
import { CRMIntegration } from "@/components/crm/crm-integration"
import { SuperUserPanel } from "@/components/dashboard/superuser-panel"
import { AIRecommendations } from "@/components/ai/ai-recommendations"
import { AIJobManager } from "@/components/jobs/ai-job-manager"
import { useFeatureAccess } from "@/hooks/use-feature-access"
import { UpgradePrompt } from "@/components/ui/upgrade-prompt"
import { ClientOnboarding } from "@/components/onboarding/client-onboarding"

interface User {
  id: string
  email: string
  name: string
  role: "basic" | "premium" | "super"
}

interface DashboardContentProps {
  user: User
  activeTab: string
}

const performanceData = [
  { name: "Jan", campaigns: 4, leads: 240, conversions: 12 },
  { name: "Feb", campaigns: 6, leads: 380, conversions: 18 },
  { name: "Mar", campaigns: 8, leads: 520, conversions: 25 },
  { name: "Apr", campaigns: 12, leads: 680, conversions: 32 },
  { name: "May", campaigns: 15, leads: 890, conversions: 45 },
  { name: "Jun", campaigns: 18, leads: 1234, conversions: 58 },
]

const channelData = [
  { name: "Email", value: 35, color: "hsl(var(--chart-1))" },
  { name: "Social Media", value: 28, color: "hsl(var(--chart-2))" },
  { name: "SEO", value: 22, color: "hsl(var(--chart-3))" },
  { name: "Paid Ads", value: 15, color: "hsl(var(--chart-4))" },
]

const recentActivities = [
  {
    id: 1,
    type: "content",
    title: 'AI generated blog post: "10 SEO Tips for 2024"',
    time: "2 hours ago",
    status: "published",
    icon: Brain,
    color: "text-primary",
  },
  {
    id: 2,
    type: "social",
    title: "Instagram post scheduled for tomorrow",
    time: "4 hours ago",
    status: "scheduled",
    icon: Share2,
    color: "text-chart-2",
  },
  {
    id: 3,
    type: "analytics",
    title: "Weekly SEO report generated",
    time: "1 day ago",
    status: "completed",
    icon: BarChart3,
    color: "text-chart-3",
  },
  {
    id: 4,
    type: "automation",
    title: 'Email campaign "Summer Sale" launched',
    time: "2 days ago",
    status: "active",
    icon: Zap,
    color: "text-chart-4",
  },
  {
    id: 5,
    type: "crm",
    title: "45 new leads imported from HubSpot",
    time: "3 days ago",
    status: "synced",
    icon: Users,
    color: "text-chart-5",
  },
]

export function DashboardContent({ user, activeTab }: DashboardContentProps) {
  const { checkFeatureAccess } = useFeatureAccess(user.role)

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-foreground">Welcome back, {user.name}!</h2>
          <p className="text-muted-foreground mt-1">Here's what's happening with your marketing campaigns today.</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="gap-1">
            <Clock className="h-3 w-3" />
            Last updated: 5 min ago
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="relative overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Campaigns</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">18</div>
            <div className="flex items-center gap-1 text-xs">
              <ArrowUpRight className="h-3 w-3 text-green-500" />
              <span className="text-green-500">+6 from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Leads</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,234</div>
            <div className="flex items-center gap-1 text-xs">
              <ArrowUpRight className="h-3 w-3 text-green-500" />
              <span className="text-green-500">+15% from last week</span>
            </div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Conversion Rate</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.7%</div>
            <div className="flex items-center gap-1 text-xs">
              <ArrowUpRight className="h-3 w-3 text-green-500" />
              <span className="text-green-500">+0.8% from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Revenue Impact</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$24.5K</div>
            <div className="flex items-center gap-1 text-xs">
              <ArrowUpRight className="h-3 w-3 text-green-500" />
              <span className="text-green-500">+12% from last month</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="performance" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="channels">Channels</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Performance Trend</CardTitle>
                <CardDescription>Monthly overview of campaigns, leads, and conversions</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="name" className="text-xs" />
                    <YAxis className="text-xs" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="leads"
                      stroke="hsl(var(--primary))"
                      fill="hsl(var(--primary))"
                      fillOpacity={0.1}
                      strokeWidth={2}
                    />
                    <Area
                      type="monotone"
                      dataKey="conversions"
                      stroke="hsl(var(--chart-2))"
                      fill="hsl(var(--chart-2))"
                      fillOpacity={0.1}
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Key Metrics</CardTitle>
                <CardDescription>Current month progress vs targets</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-medium">Email Campaign ROI</span>
                    <span className="text-muted-foreground">340% / 300%</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-medium">Social Media Engagement</span>
                    <span className="text-muted-foreground">78% / 80%</span>
                  </div>
                  <Progress value={78} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-medium">SEO Optimization Score</span>
                    <span className="text-muted-foreground">92% / 85%</span>
                  </div>
                  <Progress value={92} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-medium">Content Generation</span>
                    <span className="text-sm text-muted-foreground ml-auto">156 / 120</span>
                  </div>
                  <Progress value={100} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="channels" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Traffic Sources</CardTitle>
                <CardDescription>Distribution of leads by channel</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={channelData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {channelData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                <div className="grid grid-cols-2 gap-4 mt-4">
                  {channelData.map((channel, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: channel.color }} />
                      <span className="text-sm">{channel.name}</span>
                      <span className="text-sm text-muted-foreground ml-auto">{channel.value}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Channel Performance</CardTitle>
                <CardDescription>Detailed metrics by marketing channel</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {channelData.map((channel, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 rounded-full" style={{ backgroundColor: channel.color }} />
                      <div>
                        <p className="font-medium text-sm">{channel.name}</p>
                        <p className="text-xs text-muted-foreground">{channel.value}% of total traffic</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{Math.round(1234 * (channel.value / 100))} leads</p>
                      <div className="flex items-center gap-1 text-xs">
                        <ArrowUpRight className="h-3 w-3 text-green-500" />
                        <span className="text-green-500">+{Math.round(Math.random() * 20)}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Latest updates from your marketing automation</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity) => {
                  const Icon = activity.icon
                  return (
                    <div
                      key={activity.id}
                      className="flex items-start gap-4 p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className={`p-2 rounded-full bg-muted ${activity.color}`}>
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground">{activity.title}</p>
                        <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {activity.status}
                      </Badge>
                    </div>
                  )
                })}
              </div>
              <div className="mt-4 pt-4 border-t border-border">
                <Button variant="outline" className="w-full bg-transparent">
                  <Eye className="h-4 w-4 mr-2" />
                  View All Activity
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>AI Recommendations</CardTitle>
              <CardDescription>Get personalized AI insights for your marketing strategies</CardDescription>
            </CardHeader>
            <CardContent>
              <AIRecommendations />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )

  const renderPlaceholder = (title: string, description: string, icon: React.ReactNode) => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">{title}</h2>
        <p className="text-muted-foreground">{description}</p>
      </div>

      <Card className="text-center py-12">
        <CardContent>
          <div className="flex justify-center mb-4">{icon}</div>
          <h3 className="text-lg font-semibold mb-2">Coming Soon</h3>
          <p className="text-muted-foreground mb-4">This feature is being built and will be available soon.</p>
          <Button variant="outline">Learn More</Button>
        </CardContent>
      </Card>
    </div>
  )

  const renderFeatureContent = (
    featureName: Parameters<typeof checkFeatureAccess>[0],
    content: React.ReactNode,
    fallbackTitle?: string,
  ) => {
    const access = checkFeatureAccess(featureName)

    if (!access.canAccess) {
      return (
        <div className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-2">{fallbackTitle || "Premium Feature"}</h2>
            <p className="text-muted-foreground">This feature requires a higher plan to access.</p>
          </div>
          <UpgradePrompt
            feature={fallbackTitle || "this feature"}
            planRequired={access.planRequired || "premium"}
            message={access.upgradeMessage}
          />
        </div>
      )
    }

    return content
  }

  switch (activeTab) {
    case "overview":
      return renderOverview()
    case "onboarding":
      return <ClientOnboarding />
    case "analytics":
      return renderFeatureContent("seoBasicAnalytics", <SEOSEMDashboard />, "SEO/SEM Analytics")
    case "content":
      return renderFeatureContent("aiContentGeneration", <AIContentGenerator />, "AI Content Generation")
    case "social":
      return renderFeatureContent("socialMediaBasic", <SocialMediaManager />, "Social Media Management")
    case "calendar":
      return renderFeatureContent("basicCalendar", <ContentCalendar />, "Content Calendar")
    case "crm":
      return renderFeatureContent("basicCrm", <CRMIntegration />, "CRM Integration")
    case "recommendations":
      return renderFeatureContent("aiRecommendations", <AIRecommendations />, "AI Recommendations")
    case "jobs":
      return renderFeatureContent("aiJobManager", <AIJobManager />, "AI Job Manager")
    case "admin":
      return user.role === "super" ? (
        <SuperUserPanel />
      ) : (
        renderFeatureContent("adminPanel", <SuperUserPanel />, "Admin Panel")
      )
    case "automation":
      return renderFeatureContent(
        "workflowAutomation",
        renderPlaceholder(
          "Marketing Automation",
          "Automate your marketing workflows and campaigns.",
          <Zap className="h-12 w-12 text-primary" />,
        ),
        "Marketing Automation",
      )
    case "reports":
      return renderPlaceholder(
        "Reports & Analytics",
        "Generate comprehensive reports on your marketing performance.",
        <FileText className="h-12 w-12 text-primary" />,
      )
    default:
      return renderOverview()
  }
}
