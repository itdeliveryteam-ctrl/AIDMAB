"use client"

import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Bell, Menu, LogOut, Settings } from "lucide-react"

interface DashboardHeaderProps {
  user: {
    id: string
    email: string
    name: string
    role: "basic" | "premium" | "super"
  }
  onLogout: () => void
  sidebarOpen: boolean
  setSidebarOpen: (open: boolean) => void
}

export function DashboardHeader({ user, onLogout, sidebarOpen, setSidebarOpen }: DashboardHeaderProps) {
  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case "super":
        return "default"
      case "premium":
        return "secondary"
      default:
        return "outline"
    }
  }

  const getRoleLabel = (role: string) => {
    switch (role) {
      case "super":
        return "Super User"
      case "premium":
        return "Premium"
      default:
        return "Basic"
    }
  }

  return (
    <header className="bg-card border-b border-border h-16 flex items-center justify-between px-6 sticky top-0 z-50 backdrop-blur-sm bg-card/95">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => setSidebarOpen(!sidebarOpen)} className="lg:hidden">
          <Menu className="h-5 w-5" />
        </Button>

        <div className="flex items-center gap-3">
          <h1 className="text-xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            AI Marketing Dashboard
          </h1>
          <Badge variant={getRoleBadgeVariant(user.role)} className="animate-pulse">
            {getRoleLabel(user.role)}
          </Badge>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="sm"
          className="relative hover:bg-gradient-to-r hover:from-primary/10 hover:to-secondary/10"
        >
          <Bell className="h-5 w-5" />
          <span className="absolute -top-1 -right-1 bg-gradient-to-r from-accent to-secondary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center animate-bounce">
            3
          </span>
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              className="flex items-center gap-2 h-auto p-2 hover:bg-gradient-to-r hover:from-primary/10 hover:to-secondary/10"
            >
              <Avatar className="h-8 w-8 ring-2 ring-primary/20">
                <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white font-bold">
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="text-left hidden md:block">
                <div className="text-sm font-medium">{user.name}</div>
                <div className="text-xs text-muted-foreground">{user.email}</div>
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuItem>
              <Menu className="mr-2 h-4 w-4" />
              Profile
            </DropdownMenuItem>
            <DropdownMenuItem>
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={onLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              Sign Out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
