"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Calendar,
  Plus,
  Filter,
  Search,
  Clock,
  FileText,
  Image,
  Video,
  Share2,
  Mail,
  CheckCircle,
  AlertCircle,
  Circle,
  MoreHorizontal,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"

const contentTypes = [
  { id: "blog", name: "Blog Post", icon: FileText, color: "hsl(var(--chart-1))" },
  { id: "social", name: "Social Media", icon: Share2, color: "hsl(var(--chart-2))" },
  { id: "email", name: "Email Campaign", icon: Mail, color: "hsl(var(--chart-3))" },
  { id: "video", name: "Video Content", icon: Video, color: "hsl(var(--chart-4))" },
  { id: "image", name: "Visual Content", icon: Image, color: "hsl(var(--chart-5))" },
]

const taskStatuses = [
  { id: "todo", name: "To Do", color: "hsl(var(--muted-foreground))", icon: Circle },
  { id: "in-progress", name: "In Progress", color: "hsl(var(--chart-4))", icon: Clock },
  { id: "review", name: "Review", color: "hsl(var(--chart-2))", icon: AlertCircle },
  { id: "done", name: "Done", color: "hsl(var(--chart-1))", icon: CheckCircle },
]

const teamMembers = [
  { id: "1", name: "Sarah Johnson", role: "Content Manager", avatar: "SJ" },
  { id: "2", name: "Mike Chen", role: "Designer", avatar: "MC" },
  { id: "3", name: "Emma Davis", role: "Social Media Manager", avatar: "ED" },
  { id: "4", name: "Alex Rodriguez", role: "SEO Specialist", avatar: "AR" },
]

const sampleTasks = [
  {
    id: "1",
    title: "Q4 Marketing Campaign Blog Series",
    description: "Create 5-part blog series covering digital marketing trends for Q4",
    type: "blog",
    status: "in-progress",
    assignee: "1",
    dueDate: "2024-01-15",
    priority: "high",
    tags: ["SEO", "Content Marketing"],
  },
  {
    id: "2",
    title: "Instagram Holiday Campaign",
    description: "Design and schedule 12 Instagram posts for holiday season",
    type: "social",
    status: "todo",
    assignee: "3",
    dueDate: "2024-01-10",
    priority: "medium",
    tags: ["Social Media", "Holiday"],
  },
  {
    id: "3",
    title: "Product Launch Email Sequence",
    description: "Create 3-email sequence for new product launch",
    type: "email",
    status: "review",
    assignee: "1",
    dueDate: "2024-01-08",
    priority: "high",
    tags: ["Email Marketing", "Product Launch"],
  },
  {
    id: "4",
    title: "Tutorial Video Series",
    description: "Produce 4 tutorial videos for YouTube channel",
    type: "video",
    status: "todo",
    assignee: "2",
    dueDate: "2024-01-20",
    priority: "low",
    tags: ["Video", "Education"],
  },
]

const calendarEvents = [
  {
    id: "1",
    title: "Blog Post: SEO Trends 2024",
    date: "2024-01-08",
    type: "blog",
    status: "scheduled",
    time: "09:00",
  },
  {
    id: "2",
    title: "Instagram: Product Showcase",
    date: "2024-01-08",
    type: "social",
    status: "scheduled",
    time: "14:00",
  },
  {
    id: "3",
    title: "Email: Weekly Newsletter",
    date: "2024-01-09",
    type: "email",
    status: "draft",
    time: "10:00",
  },
  {
    id: "4",
    title: "LinkedIn: Industry Insights",
    date: "2024-01-10",
    type: "social",
    status: "scheduled",
    time: "11:00",
  },
  {
    id: "5",
    title: "Blog Post: Content Strategy",
    date: "2024-01-12",
    type: "blog",
    status: "draft",
    time: "08:00",
  },
]

export function ContentCalendar() {
  const [selectedView, setSelectedView] = useState("calendar")
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [filterType, setFilterType] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")

  const getTypeIcon = (typeId: string) => {
    const type = contentTypes.find((t) => t.id === typeId)
    return type?.icon || FileText
  }

  const getTypeColor = (typeId: string) => {
    const type = contentTypes.find((t) => t.id === typeId)
    return type?.color || "hsl(var(--muted-foreground))"
  }

  const getStatusIcon = (statusId: string) => {
    const status = taskStatuses.find((s) => s.id === statusId)
    return status?.icon || Circle
  }

  const getStatusColor = (statusId: string) => {
    const status = taskStatuses.find((s) => s.id === statusId)
    return status?.color || "hsl(var(--muted-foreground))"
  }

  const getAssignee = (assigneeId: string) => {
    return teamMembers.find((m) => m.id === assigneeId)
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "hsl(var(--destructive))"
      case "medium":
        return "hsl(var(--chart-4))"
      case "low":
        return "hsl(var(--chart-2))"
      default:
        return "hsl(var(--muted-foreground))"
    }
  }

  const renderCalendarView = () => {
    const currentMonth = selectedDate.getMonth()
    const currentYear = selectedDate.getFullYear()
    const firstDay = new Date(currentYear, currentMonth, 1)
    const lastDay = new Date(currentYear, currentMonth + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startingDayOfWeek = firstDay.getDay()

    const days = []
    const monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ]

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(<div key={`empty-${i}`} className="h-32 border border-border bg-muted/20"></div>)
    }

    // Add cells for each day of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
      const dayEvents = calendarEvents.filter((event) => event.date === dateStr)

      days.push(
        <div key={day} className="h-32 border border-border bg-card p-2 overflow-hidden">
          <div className="text-sm font-medium mb-2">{day}</div>
          <div className="space-y-1">
            {dayEvents.slice(0, 3).map((event) => {
              const Icon = getTypeIcon(event.type)
              return (
                <div
                  key={event.id}
                  className="text-xs p-1 rounded bg-muted/50 border-l-2 truncate"
                  style={{ borderLeftColor: getTypeColor(event.type) }}
                >
                  <div className="flex items-center gap-1">
                    <Icon className="h-3 w-3" />
                    <span className="truncate">{event.title}</span>
                  </div>
                  <div className="text-muted-foreground">{event.time}</div>
                </div>
              )
            })}
            {dayEvents.length > 3 && <div className="text-xs text-muted-foreground">+{dayEvents.length - 3} more</div>}
          </div>
        </div>,
      )
    }

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">
            {monthNames[currentMonth]} {currentYear}
          </h3>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSelectedDate(new Date(currentYear, currentMonth - 1, 1))}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSelectedDate(new Date(currentYear, currentMonth + 1, 1))}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-0 border border-border rounded-lg overflow-hidden">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
            <div key={day} className="bg-muted p-3 text-center text-sm font-medium border-b border-border">
              {day}
            </div>
          ))}
          {days}
        </div>
      </div>
    )
  }

  const renderKanbanView = () => {
    const filteredTasks = sampleTasks.filter((task) => {
      if (filterType !== "all" && task.type !== filterType) return false
      if (filterStatus !== "all" && task.status !== filterStatus) return false
      return true
    })

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {taskStatuses.map((status) => {
          const statusTasks = filteredTasks.filter((task) => task.status === status.id)
          const StatusIcon = status.icon

          return (
            <div key={status.id} className="space-y-4">
              <div className="flex items-center gap-2">
                <StatusIcon className="h-4 w-4" style={{ color: status.color }} />
                <h3 className="font-medium">{status.name}</h3>
                <Badge variant="outline">{statusTasks.length}</Badge>
              </div>

              <div className="space-y-3">
                {statusTasks.map((task) => {
                  const TypeIcon = getTypeIcon(task.type)
                  const assignee = getAssignee(task.assignee)

                  return (
                    <Card key={task.id} className="cursor-pointer hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-2">
                              <TypeIcon className="h-4 w-4" style={{ color: getTypeColor(task.type) }} />
                              <div
                                className="w-2 h-2 rounded-full"
                                style={{ backgroundColor: getPriorityColor(task.priority) }}
                              />
                            </div>
                            <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                              <MoreHorizontal className="h-3 w-3" />
                            </Button>
                          </div>

                          <div>
                            <h4 className="font-medium text-sm mb-1">{task.title}</h4>
                            <p className="text-xs text-muted-foreground line-clamp-2">{task.description}</p>
                          </div>

                          <div className="flex flex-wrap gap-1">
                            {task.tags.map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>

                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Clock className="h-3 w-3" />
                              <span>{task.dueDate}</span>
                            </div>
                            {assignee && (
                              <Avatar className="h-6 w-6">
                                <AvatarFallback className="text-xs">{assignee.avatar}</AvatarFallback>
                              </Avatar>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}

                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="w-full h-12 border-dashed bg-transparent">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Task
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Create New Task</DialogTitle>
                      <DialogDescription>Add a new task to your content workflow</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="task-title">Title</Label>
                        <Input id="task-title" placeholder="Enter task title" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="task-description">Description</Label>
                        <Textarea id="task-description" placeholder="Enter task description" />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Type</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                            <SelectContent>
                              {contentTypes.map((type) => {
                                const Icon = type.icon
                                return (
                                  <SelectItem key={type.id} value={type.id}>
                                    <div className="flex items-center gap-2">
                                      <Icon className="h-4 w-4" />
                                      {type.name}
                                    </div>
                                  </SelectItem>
                                )
                              })}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Assignee</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Select assignee" />
                            </SelectTrigger>
                            <SelectContent>
                              {teamMembers.map((member) => (
                                <SelectItem key={member.id} value={member.id}>
                                  <div className="flex items-center gap-2">
                                    <Avatar className="h-4 w-4">
                                      <AvatarFallback className="text-xs">{member.avatar}</AvatarFallback>
                                    </Avatar>
                                    {member.name}
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Priority</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Select priority" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="high">High</SelectItem>
                              <SelectItem value="medium">Medium</SelectItem>
                              <SelectItem value="low">Low</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Due Date</Label>
                          <Input type="date" />
                        </div>
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button variant="outline">Cancel</Button>
                        <Button>Create Task</Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          )
        })}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Content Calendar & Tasks</h2>
          <p className="text-muted-foreground">Plan and organize your content strategy with our calendar</p>
        </div>
        <div className="flex items-center gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                New Content
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Content</DialogTitle>
                <DialogDescription>Schedule new content for your marketing calendar</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="content-title">Title</Label>
                  <Input id="content-title" placeholder="Enter content title" />
                </div>
                <div className="space-y-2">
                  <Label>Content Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select content type" />
                    </SelectTrigger>
                    <SelectContent>
                      {contentTypes.map((type) => {
                        const Icon = type.icon
                        return (
                          <SelectItem key={type.id} value={type.id}>
                            <div className="flex items-center gap-2">
                              <Icon className="h-4 w-4" />
                              {type.name}
                            </div>
                          </SelectItem>
                        )
                      })}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Publish Date</Label>
                    <Input type="date" />
                  </div>
                  <div className="space-y-2">
                    <Label>Publish Time</Label>
                    <Input type="time" />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline">Cancel</Button>
                  <Button>Schedule Content</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search content..." className="pl-10 w-64" />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {contentTypes.map((type) => (
                <SelectItem key={type.id} value={type.id}>
                  {type.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              {taskStatuses.map((status) => (
                <SelectItem key={status.id} value={status.id}>
                  {status.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs value={selectedView} onValueChange={setSelectedView} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 max-w-md">
          <TabsTrigger value="calendar">
            <Calendar className="h-4 w-4 mr-2" />
            Calendar View
          </TabsTrigger>
          <TabsTrigger value="kanban">
            <Filter className="h-4 w-4 mr-2" />
            Kanban Board
          </TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="space-y-6">
          {renderCalendarView()}
        </TabsContent>

        <TabsContent value="kanban" className="space-y-6">
          {renderKanbanView()}
        </TabsContent>
      </Tabs>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Team Workload</CardTitle>
            <CardDescription>Current task distribution</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {teamMembers.map((member) => {
              const memberTasks = sampleTasks.filter((task) => task.assignee === member.id)
              return (
                <div key={member.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarFallback className="text-xs">{member.avatar}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">{member.name}</p>
                      <p className="text-xs text-muted-foreground">{member.role}</p>
                    </div>
                  </div>
                  <Badge variant="outline">{memberTasks.length} tasks</Badge>
                </div>
              )
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Upcoming Deadlines</CardTitle>
            <CardDescription>Tasks due in the next 7 days</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {sampleTasks
              .filter((task) => new Date(task.dueDate) <= new Date(Date.now() + 7 * 24 * 60 * 60 * 1000))
              .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
              .slice(0, 4)
              .map((task) => {
                const TypeIcon = getTypeIcon(task.type)
                const assignee = getAssignee(task.assignee)
                return (
                  <div key={task.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <TypeIcon className="h-4 w-4" style={{ color: getTypeColor(task.type) }} />
                      <div>
                        <p className="text-sm font-medium truncate">{task.title}</p>
                        <p className="text-xs text-muted-foreground">{task.dueDate}</p>
                      </div>
                    </div>
                    {assignee && (
                      <Avatar className="h-6 w-6">
                        <AvatarFallback className="text-xs">{assignee.avatar}</AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                )
              })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Content Performance</CardTitle>
            <CardDescription>This month's content metrics</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm">Published Content</span>
              <span className="font-medium">24 pieces</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">Avg. Engagement</span>
              <span className="font-medium">4.2%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">Content in Pipeline</span>
              <span className="font-medium">12 pieces</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">On-time Delivery</span>
              <span className="font-medium text-green-500">92%</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
