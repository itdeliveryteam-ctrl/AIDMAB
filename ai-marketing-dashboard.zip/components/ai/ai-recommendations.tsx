"use client"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Brain,
  TrendingUp,
  Target,
  Lightbulb,
  Zap,
  Calendar,
  ArrowRight,
  CheckCircle,
  Sparkles,
  RefreshCw,
  Users,
} from "lucide-react"

interface Recommendation {
  id: string
  type: "strategy" | "content" | "optimization" | "automation" | "personalization" | "ai-integration"
  priority: "high" | "medium" | "low"
  title: string
  description: string
  impact: string
  effort: string
  roi: string
  implementation: string[]
  metrics: string[]
  expert: string // Added expert attribution
  expertStrategy: string // Added expert strategy reference
}

interface AIInsight {
  category: string
  insight: string
  confidence: number
  action: string
  trendBased: boolean // Added trend indicator
}

export function AIRecommendations() {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([])
  const [insights, setInsights] = useState<AIInsight[]>([])
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState("all")

  useEffect(() => {
    // Simulate AI analysis on component mount
    analyzeMarketingData()
  }, [])

  const analyzeMarketingData = async () => {
    setIsAnalyzing(true)

    // Simulate AI analysis delay
    setTimeout(() => {
      setRecommendations(generateRecommendations())
      setInsights(generateInsights())
      setIsAnalyzing(false)
    }, 2000)
  }

  const generateRecommendations = (): Recommendation[] => [
    {
      id: "1",
      type: "ai-integration",
      priority: "high",
      title: "Implement AI-Powered Hyper-Personalization",
      description:
        "Deploy AI to create dynamic, personalized experiences that adapt in real-time based on user behavior, increasing conversion rates by up to 30%.",
      impact: "High",
      effort: "High",
      roi: "320%",
      expert: "Neil Patel & Industry Trends 2024",
      expertStrategy: "AI-powered personalization with behavioral targeting and real-time optimization",
      implementation: [
        "Set up behavioral tracking and data collection",
        "Implement dynamic content personalization engine",
        "Create AI-driven product recommendations",
        "Deploy real-time A/B testing automation",
        "Integrate predictive analytics for customer journey mapping",
      ],
      metrics: ["Conversion rate", "Engagement time", "Personalization score", "Customer lifetime value"],
    },
    {
      id: "2",
      type: "content",
      priority: "high",
      title: "Content-First Business Growth Strategy",
      description:
        "Build loyal audiences through valuable, educational content that positions your brand as a trusted authority in your industry.",
      impact: "High",
      effort: "Medium",
      roi: "280%",
      expert: "Joe Pulizzi & Ann Handley",
      expertStrategy: "Content Marketing Institute's audience-first approach with storytelling focus",
      implementation: [
        "Develop content pillars around audience pain points",
        "Create educational content series and guides",
        "Implement storytelling framework for brand messaging",
        "Build content distribution across multiple channels",
        "Establish thought leadership through industry insights",
      ],
      metrics: ["Audience growth", "Content engagement", "Brand authority score", "Lead generation"],
    },
    {
      id: "3",
      type: "strategy",
      priority: "high",
      title: "Social Media Brand Building with Authenticity",
      description:
        "Leverage authentic storytelling and personal branding to build genuine connections with your audience across social platforms.",
      impact: "High",
      effort: "Medium",
      roi: "250%",
      expert: "Gary Vaynerchuk",
      expertStrategy: "Authentic personal branding with platform-specific content strategies",
      implementation: [
        "Develop authentic brand voice and personality",
        "Create platform-specific content strategies",
        "Implement daily value-driven content posting",
        "Build community through genuine engagement",
        "Use micro-content for maximum reach",
      ],
      metrics: ["Brand sentiment", "Community growth", "Engagement rate", "Share of voice"],
    },
    {
      id: "4",
      type: "optimization",
      priority: "high",
      title: "Advanced SEO with Skyscraper Technique",
      description:
        "Implement Brian Dean's proven Skyscraper Technique to create superior content that naturally attracts high-quality backlinks.",
      impact: "High",
      effort: "Medium",
      roi: "190%",
      expert: "Brian Dean & Rand Fishkin",
      expertStrategy: "Ethical SEO with content superiority and link-building excellence",
      implementation: [
        "Research top-performing content in your niche",
        "Create 10x better versions of successful content",
        "Implement comprehensive keyword research strategy",
        "Build ethical link-building outreach campaigns",
        "Optimize for search experience (SXO) not just SEO",
      ],
      metrics: ["Organic traffic", "Keyword rankings", "Backlink quality", "Domain authority"],
    },
    {
      id: "5",
      type: "automation",
      priority: "medium",
      title: "AI-Powered Marketing Automation",
      description:
        "Deploy intelligent automation that adapts campaigns in real-time based on performance data and customer behavior patterns.",
      impact: "High",
      effort: "High",
      roi: "340%",
      expert: "Larry Kim & 2024 AI Trends",
      expertStrategy: "AI-driven automation with chatbot integration and predictive optimization",
      implementation: [
        "Set up AI-powered lead scoring and segmentation",
        "Deploy intelligent chatbots for 24/7 customer service",
        "Implement predictive analytics for campaign optimization",
        "Create automated nurture sequences with AI personalization",
        "Build real-time campaign adjustment algorithms",
      ],
      metrics: ["Automation efficiency", "Lead quality score", "Response time", "Conversion rate"],
    },
    {
      id: "6",
      type: "personalization",
      priority: "medium",
      title: "Customer-Centric Experience Design",
      description:
        "Focus on creating remarkable customer experiences that build trust and foster long-term relationships through value-driven interactions.",
      impact: "High",
      effort: "Medium",
      roi: "220%",
      expert: "Seth Godin & Jay Baer",
      expertStrategy: "Remarkable customer experience with trust-building and value creation",
      implementation: [
        "Map complete customer journey touchpoints",
        "Design value-first customer interactions",
        "Implement omnichannel experience consistency",
        "Create customer feedback loops and optimization",
        "Build trust through transparency and authenticity",
      ],
      metrics: ["Customer satisfaction", "Net promoter score", "Customer lifetime value", "Retention rate"],
    },
    {
      id: "7",
      type: "strategy",
      priority: "medium",
      title: "Facebook & Social Media Mastery",
      description:
        "Maximize reach and engagement on social platforms with advanced targeting, community building, and platform-specific strategies.",
      impact: "Medium",
      effort: "Medium",
      roi: "180%",
      expert: "Mari Smith",
      expertStrategy: "Platform-specific social media optimization with community engagement focus",
      implementation: [
        "Develop platform-specific content calendars",
        "Implement advanced Facebook advertising strategies",
        "Build engaged communities through consistent value delivery",
        "Use social listening for real-time engagement opportunities",
        "Create viral content frameworks for maximum reach",
      ],
      metrics: ["Social reach", "Community engagement", "Social conversion rate", "Brand mentions"],
    },
    {
      id: "8",
      type: "optimization",
      priority: "low",
      title: "First-Party Data Strategy & Privacy Compliance",
      description:
        "Build robust first-party data collection and management systems to prepare for the cookieless future while maintaining customer trust.",
      impact: "Medium",
      effort: "High",
      roi: "150%",
      expert: "2024 Privacy Trends",
      expertStrategy: "Privacy-first marketing with ethical data usage and transparency",
      implementation: [
        "Implement comprehensive first-party data collection",
        "Build customer data platform (CDP) integration",
        "Create transparent data usage policies",
        "Develop consent management systems",
        "Design value exchange for data sharing",
      ],
      metrics: ["Data quality score", "Compliance rate", "Customer trust index", "Data utilization rate"],
    },
  ]

  const generateInsights = (): AIInsight[] => [
    {
      category: "AI & Automation Trends",
      insight:
        "AI-powered marketing automation is expected to increase efficiency by 80% while reducing manual intervention, with specialized AI agents becoming creative partners for marketers",
      confidence: 95,
      action: "Implement AI automation tools for content creation, audience segmentation, and campaign optimization",
      trendBased: true,
    },
    {
      category: "Hyper-Personalization Impact",
      insight:
        "Personalized campaigns powered by AI can boost conversion rates by up to 30%, with dynamic content adjusting to consumer needs in real-time",
      confidence: 92,
      action: "Deploy AI-driven personalization engines that adapt content based on user behavior and preferences",
      trendBased: true,
    },
    {
      category: "Content Authority Building",
      insight:
        "Educational and how-to content generates 3x more leads than promotional content, following Joe Pulizzi's content-first business growth model",
      confidence: 88,
      action: "Shift content strategy to 70% educational content that builds audience trust and authority",
      trendBased: false,
    },
    {
      category: "Social Media Authenticity",
      insight:
        "Authentic storytelling and personal branding on social media drive 65% higher engagement rates, following Gary Vaynerchuk's approach",
      confidence: 85,
      action: "Develop authentic brand voice and implement daily value-driven content across social platforms",
      trendBased: false,
    },
    {
      category: "Search Experience Optimization",
      insight:
        "SXO (Search Experience Optimization) is replacing traditional SEO, focusing on user experience alongside search rankings for better results",
      confidence: 90,
      action: "Optimize for complete search experience including page speed, user intent, and content quality",
      trendBased: true,
    },
    {
      category: "Customer Experience Priority",
      insight:
        "Businesses focusing on remarkable customer experiences see 5x higher customer lifetime value, following Seth Godin's trust-building principles",
      confidence: 87,
      action: "Design customer-centric touchpoints that prioritize value delivery over sales pitches",
      trendBased: false,
    },
  ]

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "strategy":
        return Target
      case "content":
        return Lightbulb
      case "optimization":
        return TrendingUp
      case "automation":
        return Zap
      case "personalization":
        return Users
      case "ai-integration":
        return Brain
      default:
        return Brain
    }
  }

  const filteredRecommendations =
    selectedCategory === "all" ? recommendations : recommendations.filter((rec) => rec.type === selectedCategory)

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">AI Marketing Recommendations</h2>
        <p className="text-muted-foreground">
          Expert-backed strategies from top digital marketing leaders and 2024 AI trends
        </p>
      </div>

      {isAnalyzing && (
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-primary animate-pulse" />
                <span className="text-sm font-medium">AI is analyzing marketing trends and expert strategies...</span>
              </div>
              <Progress value={65} className="h-2" />
              <p className="text-xs text-muted-foreground">
                Processing insights from Neil Patel, Gary Vaynerchuk, Seth Godin, and 2024 marketing trends
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="recommendations" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="recommendations">Expert Recommendations</TabsTrigger>
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
          <TabsTrigger value="implementation">Implementation</TabsTrigger>
        </TabsList>

        <TabsContent value="recommendations" className="space-y-4">
          <div className="flex gap-2 mb-4 flex-wrap">
            <Button
              variant={selectedCategory === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("all")}
            >
              All
            </Button>
            <Button
              variant={selectedCategory === "strategy" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("strategy")}
            >
              Strategy
            </Button>
            <Button
              variant={selectedCategory === "content" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("content")}
            >
              Content
            </Button>
            <Button
              variant={selectedCategory === "optimization" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("optimization")}
            >
              SEO/Optimization
            </Button>
            <Button
              variant={selectedCategory === "automation" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("automation")}
            >
              Automation
            </Button>
            <Button
              variant={selectedCategory === "personalization" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("personalization")}
            >
              Personalization
            </Button>
            <Button
              variant={selectedCategory === "ai-integration" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("ai-integration")}
            >
              AI Integration
            </Button>
          </div>

          <div className="grid gap-4">
            {filteredRecommendations.map((rec) => {
              const Icon = getTypeIcon(rec.type)
              return (
                <Card key={rec.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <Icon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{rec.title}</CardTitle>
                          <div className="flex items-center gap-2 mt-1">
                            <div className={`w-2 h-2 rounded-full ${getPriorityColor(rec.priority)}`} />
                            <span className="text-xs text-muted-foreground capitalize">{rec.priority} Priority</span>
                            <Badge variant="outline" className="text-xs">
                              {rec.type}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-1 mt-1">
                            <Sparkles className="h-3 w-3 text-amber-500" />
                            <span className="text-xs text-amber-600 font-medium">{rec.expert}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-green-600">{rec.roi}</div>
                        <div className="text-xs text-muted-foreground">Expected ROI</div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground">{rec.description}</p>
                    <div className="p-3 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <Target className="h-4 w-4 text-blue-600" />
                        <span className="text-sm font-medium text-blue-900 dark:text-blue-100">Expert Strategy:</span>
                      </div>
                      <p className="text-sm text-blue-800 dark:text-blue-200">{rec.expertStrategy}</p>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <div className="font-medium text-foreground">Impact</div>
                        <div className="text-muted-foreground">{rec.impact}</div>
                      </div>
                      <div>
                        <div className="font-medium text-foreground">Effort</div>
                        <div className="text-muted-foreground">{rec.effort}</div>
                      </div>
                      <div>
                        <div className="font-medium text-foreground">Timeline</div>
                        <div className="text-muted-foreground">2-6 weeks</div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="font-medium text-sm">Implementation Steps:</div>
                      <ul className="space-y-1">
                        {rec.implementation.slice(0, 3).map((step, index) => (
                          <li key={index} className="flex items-center gap-2 text-sm text-muted-foreground">
                            <CheckCircle className="h-3 w-3 text-green-500" />
                            {step}
                          </li>
                        ))}
                        {rec.implementation.length > 3 && (
                          <li className="text-sm text-muted-foreground">+{rec.implementation.length - 3} more steps</li>
                        )}
                      </ul>
                    </div>
                    <div className="flex justify-between items-center pt-2">
                      <div className="flex gap-2">
                        {rec.metrics.slice(0, 2).map((metric, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {metric}
                          </Badge>
                        ))}
                      </div>
                      <Button
                        size="sm"
                        className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                      >
                        Implement
                        <ArrowRight className="h-3 w-3 ml-1" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <div className="grid gap-4">
            {insights.map((insight, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-base">{insight.category}</CardTitle>
                      {insight.trendBased && (
                        <Badge
                          variant="outline"
                          className="text-xs bg-gradient-to-r from-orange-100 to-red-100 text-orange-800 border-orange-200"
                        >
                          <TrendingUp className="h-3 w-3 mr-1" />
                          2024 Trend
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress value={insight.confidence} className="w-20 h-2" />
                      <span className="text-sm text-muted-foreground">{insight.confidence}%</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-muted-foreground">{insight.insight}</p>
                  <div className="flex items-center gap-2 p-3 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded-lg">
                    <Lightbulb className="h-4 w-4 text-blue-600" />
                    <span className="text-sm font-medium text-blue-900 dark:text-blue-100">Recommended Action:</span>
                    <span className="text-sm text-blue-800 dark:text-blue-200">{insight.action}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="implementation" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Expert-Backed Implementation Roadmap
              </CardTitle>
              <CardDescription>Prioritized action plan based on top marketing expert strategies</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {[
                  {
                    phase: "Week 1-2",
                    title: "Foundation & Quick Wins",
                    items: [
                      "Implement AI-powered personalization basics (Neil Patel approach)",
                      "Set up authentic social media content strategy (Gary Vaynerchuk method)",
                      "Begin content-first audience building (Joe Pulizzi framework)",
                    ],
                    color: "bg-green-500",
                    expert: "Neil Patel, Gary Vaynerchuk, Joe Pulizzi",
                  },
                  {
                    phase: "Week 3-8",
                    title: "Content & SEO Excellence",
                    items: [
                      "Deploy Skyscraper Technique for content superiority (Brian Dean strategy)",
                      "Build customer-centric experience touchpoints (Seth Godin principles)",
                      "Launch Facebook and social media mastery campaigns (Mari Smith tactics)",
                    ],
                    color: "bg-blue-500",
                    expert: "Brian Dean, Seth Godin, Mari Smith",
                  },
                  {
                    phase: "Week 9-12",
                    title: "Advanced AI & Automation",
                    items: [
                      "Full AI marketing automation deployment (Larry Kim approach)",
                      "Implement first-party data strategy for privacy compliance",
                      "Advanced hyper-personalization with predictive analytics",
                    ],
                    color: "bg-purple-500",
                    expert: "Larry Kim, 2024 AI Trends",
                  },
                ].map((phase, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className={`w-4 h-4 rounded-full ${phase.color}`} />
                      {index < 2 && <div className="w-0.5 h-20 bg-border mt-2" />}
                    </div>
                    <div className="flex-1 pb-8">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-medium">{phase.phase}</span>
                        <Badge variant="outline">{phase.title}</Badge>
                      </div>
                      <div className="flex items-center gap-1 mb-3">
                        <Sparkles className="h-3 w-3 text-amber-500" />
                        <span className="text-xs text-amber-600 font-medium">{phase.expert}</span>
                      </div>
                      <ul className="space-y-2">
                        {phase.items.map((item, itemIndex) => (
                          <li key={itemIndex} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <CheckCircle className="h-3 w-3 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-center">
        <Button
          onClick={analyzeMarketingData}
          disabled={isAnalyzing}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        >
          {isAnalyzing ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              Analyzing Expert Strategies...
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4 mr-2" />
              Refresh Expert Analysis
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
