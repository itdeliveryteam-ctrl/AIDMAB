"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Brain,
  FileText,
  Mail,
  Share2,
  Globe,
  Wand2,
  Copy,
  Download,
  Calendar,
  Target,
  Sparkles,
  RefreshCw,
} from "lucide-react"

interface ContentTemplate {
  id: string
  name: string
  type: "blog" | "social" | "email" | "landing"
  description: string
  icon: React.ComponentType<{ className?: string }>
}

const contentTemplates: ContentTemplate[] = [
  {
    id: "blog-seo",
    name: "SEO Blog Post",
    type: "blog",
    description: "SEO-optimized blog post with keywords and meta descriptions",
    icon: FileText,
  },
  {
    id: "social-engagement",
    name: "Social Media Post",
    type: "social",
    description: "Engaging social media content with hashtags",
    icon: Share2,
  },
  {
    id: "email-campaign",
    name: "Email Campaign",
    type: "email",
    description: "Personalized email marketing campaign",
    icon: Mail,
  },
  {
    id: "landing-conversion",
    name: "Landing Page",
    type: "landing",
    description: "High-converting landing page copy",
    icon: Globe,
  },
]

export function AIContentGenerator() {
  const [selectedTemplate, setSelectedTemplate] = useState<ContentTemplate | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedContent, setGeneratedContent] = useState("")
  const [contentPrompt, setContentPrompt] = useState("")
  const [targetAudience, setTargetAudience] = useState("")
  const [keywords, setKeywords] = useState("")
  const [tone, setTone] = useState("")

  const handleGenerate = async () => {
    if (!selectedTemplate || !contentPrompt) return

    setIsGenerating(true)

    // Simulate AI content generation
    setTimeout(() => {
      const sampleContent = generateSampleContent(selectedTemplate.type, contentPrompt, tone)
      setGeneratedContent(sampleContent)
      setIsGenerating(false)
    }, 3000)
  }

  const generateSampleContent = (type: string, prompt: string, tone: string) => {
    const toneAdjective = tone === "professional" ? "expert" : tone === "casual" ? "friendly" : "engaging"

    switch (type) {
      case "blog":
        return `# ${prompt}\n\nIn today's digital landscape, ${prompt.toLowerCase()} has become increasingly important for businesses looking to stay competitive. This ${toneAdjective} guide will walk you through the essential strategies and best practices.\n\n## Key Benefits\n\n- Improved brand visibility\n- Enhanced customer engagement\n- Increased conversion rates\n- Better ROI on marketing spend\n\n## Getting Started\n\nTo begin implementing these strategies, consider the following steps:\n\n1. **Research your target audience** - Understanding your customers is crucial\n2. **Develop a content strategy** - Plan your approach systematically\n3. **Measure and optimize** - Track performance and make improvements\n\n## Conclusion\n\nBy following these guidelines, you'll be well on your way to achieving your marketing goals. Remember to stay consistent and always focus on providing value to your audience.`

      case "social":
        return `🚀 ${prompt}\n\nDiscover how this game-changing approach can transform your business! Our latest insights show incredible results.\n\n✨ Key highlights:\n• 300% increase in engagement\n• 50% boost in conversions\n• Streamlined workflow\n\nReady to level up? Link in bio! 👆\n\n#Marketing #DigitalTransformation #BusinessGrowth #Innovation #Success`

      case "email":
        return `Subject: ${prompt} - Don't Miss Out!\n\nHi [First Name],\n\nI hope this email finds you well! I wanted to share something exciting that could make a real difference for your business.\n\n${prompt} is becoming essential for companies that want to stay ahead of the competition. Here's what you need to know:\n\n🎯 **Why it matters:**\n- Increased efficiency by 40%\n- Better customer satisfaction\n- Reduced operational costs\n\n🚀 **What's next:**\nI'd love to show you how this can work for your specific situation. Would you be interested in a quick 15-minute call this week?\n\nBest regards,\n[Your Name]\n\nP.S. Early adopters are seeing incredible results - don't wait too long!`

      case "landing":
        return `# Transform Your Business with ${prompt}\n\n## The Solution You've Been Looking For\n\nAre you tired of struggling with outdated methods? Our innovative approach to ${prompt.toLowerCase()} delivers results that speak for themselves.\n\n### Why Choose Us?\n\n✅ **Proven Results** - 95% customer satisfaction rate\n✅ **Expert Team** - Industry leaders with 10+ years experience\n✅ **Fast Implementation** - See results in just 30 days\n✅ **24/7 Support** - We're here when you need us\n\n### What Our Clients Say\n\n*"This solution completely transformed how we approach ${prompt.toLowerCase()}. The results exceeded our expectations!"*\n- Sarah Johnson, CEO of TechCorp\n\n### Ready to Get Started?\n\nJoin thousands of satisfied customers who have already transformed their business.\n\n**[Get Started Today - Free Trial]**\n\nNo credit card required • Cancel anytime • 30-day money-back guarantee`

      default:
        return `Generated content for: ${prompt}\n\nThis is a sample of AI-generated content that would be created based on your specifications.`
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedContent)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">AI Content Generation</h2>
        <p className="text-muted-foreground">Create high-quality content using artificial intelligence</p>
      </div>

      <Tabs defaultValue="templates" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="generator">Generator</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="templates" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {contentTemplates.map((template) => {
              const Icon = template.icon
              return (
                <Card
                  key={template.id}
                  className={`cursor-pointer transition-all hover:shadow-md ${
                    selectedTemplate?.id === template.id ? "ring-2 ring-primary" : ""
                  }`}
                  onClick={() => setSelectedTemplate(template)}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-base">{template.name}</CardTitle>
                        <Badge variant="outline" className="text-xs mt-1">
                          {template.type}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>{template.description}</CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {selectedTemplate && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wand2 className="h-5 w-5" />
                  Configure {selectedTemplate.name}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="prompt">Content Topic/Prompt</Label>
                    <Input
                      id="prompt"
                      placeholder="e.g., Digital Marketing Trends 2024"
                      value={contentPrompt}
                      onChange={(e) => setContentPrompt(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="audience">Target Audience</Label>
                    <Input
                      id="audience"
                      placeholder="e.g., Small business owners"
                      value={targetAudience}
                      onChange={(e) => setTargetAudience(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="keywords">Keywords (comma-separated)</Label>
                    <Input
                      id="keywords"
                      placeholder="e.g., SEO, marketing, automation"
                      value={keywords}
                      onChange={(e) => setKeywords(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tone">Tone of Voice</Label>
                    <Select value={tone} onValueChange={setTone}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select tone" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="professional">Professional</SelectItem>
                        <SelectItem value="casual">Casual</SelectItem>
                        <SelectItem value="enthusiastic">Enthusiastic</SelectItem>
                        <SelectItem value="authoritative">Authoritative</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button onClick={handleGenerate} disabled={!contentPrompt || isGenerating} className="w-full">
                  {isGenerating ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Generating Content...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 mr-2" />
                      Generate Content
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="generator" className="space-y-4">
          {isGenerating && (
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-primary animate-pulse" />
                    <span className="text-sm font-medium">AI is generating your content...</span>
                  </div>
                  <Progress value={33} className="h-2" />
                  <p className="text-xs text-muted-foreground">
                    Analyzing your requirements and creating optimized content
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {generatedContent && !isGenerating && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-primary" />
                    Generated Content
                  </CardTitle>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={copyToClipboard}>
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                    <Button variant="outline" size="sm">
                      <Calendar className="h-4 w-4 mr-2" />
                      Schedule
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Textarea
                    value={generatedContent}
                    onChange={(e) => setGeneratedContent(e.target.value)}
                    className="min-h-[400px] font-mono text-sm"
                  />
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>{generatedContent.length} characters</span>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1">
                        <Target className="h-4 w-4" />
                        <span>SEO Score: 85%</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Brain className="h-4 w-4" />
                        <span>Readability: Good</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Content History</CardTitle>
              <CardDescription>Your recently generated content</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    title: "Digital Marketing Trends 2024",
                    type: "Blog Post",
                    date: "2 hours ago",
                    status: "Published",
                  },
                  {
                    title: "Summer Sale Campaign",
                    type: "Email Campaign",
                    date: "1 day ago",
                    status: "Scheduled",
                  },
                  {
                    title: "Product Launch Announcement",
                    type: "Social Media",
                    date: "3 days ago",
                    status: "Draft",
                  },
                ].map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{item.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {item.type} • {item.date}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge
                        variant={
                          item.status === "Published"
                            ? "default"
                            : item.status === "Scheduled"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {item.status}
                      </Badge>
                      <Button variant="ghost" size="sm">
                        View
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
