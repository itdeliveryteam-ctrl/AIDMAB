"use client"
import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Users,
  Phone,
  Mail,
  Calendar,
  DollarSign,
  TrendingUp,
  CheckCircle,
  AlertCircle,
  Clock,
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Send as Sync,
  Settings,
  ExternalLink,
  Target,
} from "lucide-react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts"

const crmConnections = [
  {
    id: "salesforce",
    name: "Salesforce",
    status: "connected",
    lastSync: "2 minutes ago",
    contacts: 2847,
    deals: 156,
    logo: "/salesforce-logo.png",
  },
  {
    id: "hubspot",
    name: "HubSpot",
    status: "connected",
    lastSync: "5 minutes ago",
    contacts: 1923,
    deals: 89,
    logo: "/hubspot-logo.png",
  },
  {
    id: "pipedrive",
    name: "Pipedrive",
    status: "disconnected",
    lastSync: "Never",
    contacts: 0,
    deals: 0,
    logo: "/pipedrive-logo.png",
  },
  {
    id: "zoho",
    name: "Zoho CRM",
    status: "error",
    lastSync: "2 hours ago",
    contacts: 1456,
    deals: 67,
    logo: "/zoho-logo.png",
  },
]

const contacts = [
  {
    id: 1,
    name: "Sarah Johnson",
    email: "sarah.johnson@techcorp.com",
    company: "TechCorp Inc.",
    phone: "+1 (555) 123-4567",
    status: "hot",
    value: "$45,000",
    lastContact: "2 hours ago",
    source: "Website",
    avatar: "/professional-woman.png",
  },
  {
    id: 2,
    name: "Michael Chen",
    email: "m.chen@innovate.io",
    company: "Innovate Solutions",
    phone: "+1 (555) 987-6543",
    status: "warm",
    value: "$28,500",
    lastContact: "1 day ago",
    source: "LinkedIn",
    avatar: "/professional-man.png",
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    email: "emily@startupxyz.com",
    company: "StartupXYZ",
    phone: "+1 (555) 456-7890",
    status: "cold",
    value: "$12,000",
    lastContact: "3 days ago",
    source: "Email Campaign",
    avatar: "/business-woman.png",
  },
  {
    id: 4,
    name: "David Kim",
    email: "david.kim@enterprise.com",
    company: "Enterprise Corp",
    phone: "+1 (555) 321-0987",
    status: "hot",
    value: "$67,500",
    lastContact: "4 hours ago",
    source: "Referral",
    avatar: "/executive-man.png",
  },
]

const deals = [
  {
    id: 1,
    title: "TechCorp Enterprise License",
    company: "TechCorp Inc.",
    value: 45000,
    stage: "Proposal",
    probability: 75,
    closeDate: "2024-02-15",
    contact: "Sarah Johnson",
  },
  {
    id: 2,
    title: "Innovate Solutions Package",
    company: "Innovate Solutions",
    value: 28500,
    stage: "Negotiation",
    probability: 60,
    closeDate: "2024-02-28",
    contact: "Michael Chen",
  },
  {
    id: 3,
    title: "StartupXYZ Basic Plan",
    company: "StartupXYZ",
    value: 12000,
    stage: "Qualification",
    probability: 25,
    closeDate: "2024-03-10",
    contact: "Emily Rodriguez",
  },
  {
    id: 4,
    title: "Enterprise Corp Premium",
    company: "Enterprise Corp",
    value: 67500,
    stage: "Proposal",
    probability: 80,
    closeDate: "2024-02-20",
    contact: "David Kim",
  },
]

const pipelineData = [
  { stage: "Lead", count: 45, value: 234000 },
  { stage: "Qualified", count: 28, value: 189000 },
  { stage: "Proposal", count: 15, value: 145000 },
  { stage: "Negotiation", count: 8, value: 98000 },
  { stage: "Closed Won", count: 12, value: 156000 },
]

const activityData = [
  { name: "Jan", calls: 45, emails: 123, meetings: 12 },
  { name: "Feb", calls: 52, emails: 145, meetings: 18 },
  { name: "Mar", calls: 38, emails: 98, meetings: 15 },
  { name: "Apr", calls: 61, emails: 167, meetings: 22 },
  { name: "May", calls: 55, emails: 134, meetings: 19 },
  { name: "Jun", calls: 67, emails: 189, meetings: 25 },
]

const statusColors = {
  hot: "bg-red-500",
  warm: "bg-orange-500",
  cold: "bg-blue-500",
}

const getStatusColor = (status: string) => {
  return statusColors[status as keyof typeof statusColors] || "bg-gray-500"
}

export function CRMIntegration() {
  const [selectedContact, setSelectedContact] = useState<number | null>(null)
  const [searchTerm, setSearchTerm] = useState("")

  const filteredContacts = contacts.filter(
    (contact) =>
      contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.email.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            CRM Integration
          </h2>
          <p className="text-muted-foreground mt-1">
            Manage your customer relationships and sales pipeline in one place.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Sync className="h-4 w-4 mr-2" />
            Sync All
          </Button>
          <Button size="sm" className="bg-gradient-to-r from-primary to-secondary">
            <Plus className="h-4 w-4 mr-2" />
            Add Integration
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="contacts">Contacts</TabsTrigger>
          <TabsTrigger value="deals">Deals</TabsTrigger>
          <TabsTrigger value="pipeline">Pipeline</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent" />
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Contacts</CardTitle>
                <Users className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">4,770</div>
                <div className="flex items-center gap-1 text-xs">
                  <TrendingUp className="h-3 w-3 text-green-500" />
                  <span className="text-green-500">+12% from last month</span>
                </div>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-secondary/10 to-transparent" />
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Active Deals</CardTitle>
                <Target className="h-4 w-4 text-secondary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">312</div>
                <div className="flex items-center gap-1 text-xs">
                  <TrendingUp className="h-3 w-3 text-green-500" />
                  <span className="text-green-500">+8% from last week</span>
                </div>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-accent/10 to-transparent" />
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Pipeline Value</CardTitle>
                <DollarSign className="h-4 w-4 text-accent" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$1.2M</div>
                <div className="flex items-center gap-1 text-xs">
                  <TrendingUp className="h-3 w-3 text-green-500" />
                  <span className="text-green-500">+15% from last month</span>
                </div>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-chart-4/10 to-transparent" />
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Win Rate</CardTitle>
                <CheckCircle className="h-4 w-4 text-chart-4" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">68%</div>
                <div className="flex items-center gap-1 text-xs">
                  <TrendingUp className="h-3 w-3 text-green-500" />
                  <span className="text-green-500">+3% from last quarter</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Sales Activity Trends</CardTitle>
                <CardDescription>Monthly breakdown of sales activities</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={activityData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="name" className="text-xs" />
                    <YAxis className="text-xs" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="calls"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--primary))" }}
                    />
                    <Line
                      type="monotone"
                      dataKey="emails"
                      stroke="hsl(var(--secondary))"
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--secondary))" }}
                    />
                    <Line
                      type="monotone"
                      dataKey="meetings"
                      stroke="hsl(var(--accent))"
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--accent))" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Pipeline Overview</CardTitle>
                <CardDescription>Current deals by stage</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={pipelineData} layout="horizontal">
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis type="number" className="text-xs" />
                    <YAxis dataKey="stage" type="category" className="text-xs" width={80} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Bar dataKey="count" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="contacts" className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search contacts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
              <Button size="sm" className="bg-gradient-to-r from-primary to-secondary">
                <Plus className="h-4 w-4 mr-2" />
                Add Contact
              </Button>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Contacts ({filteredContacts.length})</CardTitle>
              <CardDescription>Manage your customer and prospect database</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredContacts.map((contact) => (
                  <div
                    key={contact.id}
                    className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => setSelectedContact(contact.id)}
                  >
                    <div className="flex items-center gap-4">
                      <Avatar>
                        <AvatarImage src={contact.avatar || "/placeholder.svg"} alt={contact.name} />
                        <AvatarFallback>
                          {contact.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium">{contact.name}</h4>
                          <div className={`w-2 h-2 rounded-full ${getStatusColor(contact.status)}`} />
                        </div>
                        <p className="text-sm text-muted-foreground">{contact.company}</p>
                        <div className="flex items-center gap-4 mt-1">
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Mail className="h-3 w-3" />
                            {contact.email}
                          </span>
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Phone className="h-3 w-3" />
                            {contact.phone}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-sm">{contact.value}</p>
                      <p className="text-xs text-muted-foreground">Last contact: {contact.lastContact}</p>
                      <Badge variant="outline" className="mt-1 text-xs">
                        {contact.source}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="deals" className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-semibold">Active Deals</h3>
              <p className="text-sm text-muted-foreground">Track your sales opportunities</p>
            </div>
            <Button size="sm" className="bg-gradient-to-r from-primary to-secondary">
              <Plus className="h-4 w-4 mr-2" />
              New Deal
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {deals.map((deal) => (
              <Card key={deal.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-base">{deal.title}</CardTitle>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </div>
                  <CardDescription>{deal.company}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-2xl font-bold text-primary">${deal.value.toLocaleString()}</span>
                    <Badge variant="outline">{deal.stage}</Badge>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Probability</span>
                      <span>{deal.probability}%</span>
                    </div>
                    <Progress value={deal.probability} className="h-2" />
                  </div>
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {deal.closeDate}
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      {deal.contact}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="pipeline" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sales Pipeline</CardTitle>
              <CardDescription>Visual representation of your sales funnel</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                {pipelineData.map((stage, index) => (
                  <div key={stage.stage} className="text-center">
                    <div className="relative">
                      <div
                        className="w-full h-32 rounded-lg flex items-center justify-center text-white font-bold text-lg mb-2"
                        style={{
                          background: `linear-gradient(135deg, hsl(var(--primary)) ${index * 20}%, hsl(var(--secondary)) 100%)`,
                        }}
                      >
                        {stage.count}
                      </div>
                      <h4 className="font-medium text-sm">{stage.stage}</h4>
                      <p className="text-xs text-muted-foreground">${stage.value.toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {crmConnections.map((connection) => (
              <Card key={connection.id} className="relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent" />
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img
                        src={connection.logo || "/placeholder.svg"}
                        alt={`${connection.name} logo`}
                        className="w-10 h-10 rounded-lg"
                      />
                      <div>
                        <CardTitle className="text-lg">{connection.name}</CardTitle>
                        <div className="flex items-center gap-2 mt-1">
                          {connection.status === "connected" && (
                            <Badge variant="default" className="bg-green-500">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Connected
                            </Badge>
                          )}
                          {connection.status === "disconnected" && (
                            <Badge variant="secondary">
                              <Clock className="h-3 w-3 mr-1" />
                              Disconnected
                            </Badge>
                          )}
                          {connection.status === "error" && (
                            <Badge variant="destructive">
                              <AlertCircle className="h-3 w-3 mr-1" />
                              Error
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Settings className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Contacts</p>
                      <p className="text-2xl font-bold">{connection.contacts.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Deals</p>
                      <p className="text-2xl font-bold">{connection.deals}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Last sync: {connection.lastSync}</p>
                    <div className="flex gap-2">
                      {connection.status === "connected" ? (
                        <>
                          <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                            <Sync className="h-4 w-4 mr-2" />
                            Sync Now
                          </Button>
                          <Button variant="outline" size="sm">
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        </>
                      ) : (
                        <Button size="sm" className="flex-1 bg-gradient-to-r from-primary to-secondary">
                          Connect
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
