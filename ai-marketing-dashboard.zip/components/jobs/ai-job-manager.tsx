"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Brain,
  Clock,
  CheckCircle,
  AlertCircle,
  Play,
  Pause,
  Settings,
  Plus,
  Target,
  TrendingUp,
  Users,
  Calendar,
  BarChart3,
  Lightbulb,
  Wand2,
  Rocket,
} from "lucide-react"

interface AIJob {
  id: string
  title: string
  description: string
  type: "content" | "seo" | "social" | "email" | "analytics" | "automation"
  status: "pending" | "running" | "completed" | "failed"
  priority: "low" | "medium" | "high" | "urgent"
  progress: number
  estimatedTime: string
  aiSuggestions: string[]
  customizations: Record<string, any>
  createdAt: string
  completedAt?: string
  results?: any
}

interface AISuggestion {
  id: string
  category: string
  title: string
  description: string
  impact: "low" | "medium" | "high"
  effort: "low" | "medium" | "high"
  roi: number
  implementation: string[]
  expert: string
  trend: string
}

const mockJobs: AIJob[] = [
  {
    id: "1",
    title: "SEO Content Optimization Campaign",
    description: "AI-powered optimization of 50 blog posts for better search rankings",
    type: "seo",
    status: "running",
    priority: "high",
    progress: 65,
    estimatedTime: "2 hours remaining",
    aiSuggestions: ["Focus on long-tail keywords", "Optimize meta descriptions", "Add internal linking"],
    customizations: { targetKeywords: ["digital marketing", "SEO tips"], contentLength: "medium" },
    createdAt: "2024-01-15T10:30:00Z",
  },
  {
    id: "2",
    title: "Social Media Content Generation",
    description: "Generate 30 days of social media posts across all platforms",
    type: "social",
    status: "completed",
    priority: "medium",
    progress: 100,
    estimatedTime: "Completed",
    aiSuggestions: ["Use trending hashtags", "Include visual elements", "Schedule optimal times"],
    customizations: { platforms: ["instagram", "linkedin", "twitter"], tone: "professional" },
    createdAt: "2024-01-14T09:15:00Z",
    completedAt: "2024-01-14T11:45:00Z",
  },
  {
    id: "3",
    title: "Email Campaign Personalization",
    description: "AI-driven personalization of email campaigns for 10,000 subscribers",
    type: "email",
    status: "pending",
    priority: "urgent",
    progress: 0,
    estimatedTime: "45 minutes",
    aiSuggestions: ["Segment by behavior", "Dynamic subject lines", "A/B test send times"],
    customizations: { segments: 5, personalizationLevel: "high" },
    createdAt: "2024-01-15T14:20:00Z",
  },
]

const aiSuggestions: AISuggestion[] = [
  {
    id: "1",
    category: "Content Strategy",
    title: "Implement Skyscraper Technique",
    description: "Create superior content by analyzing top-performing articles in your niche",
    impact: "high",
    effort: "medium",
    roi: 340,
    implementation: [
      "Research top 10 articles",
      "Identify content gaps",
      "Create comprehensive guide",
      "Build backlinks",
    ],
    expert: "Brian Dean",
    trend: "Content Excellence",
  },
  {
    id: "2",
    category: "Social Media",
    title: "AI-Powered Video Content",
    description: "Generate personalized video content at scale using AI automation",
    impact: "high",
    effort: "low",
    roi: 280,
    implementation: ["Set up AI video tools", "Create templates", "Automate distribution", "Track engagement"],
    expert: "Gary Vaynerchuk",
    trend: "AI Automation",
  },
  {
    id: "3",
    category: "Email Marketing",
    title: "Hyper-Personalization Engine",
    description: "Implement AI-driven hyper-personalization for email campaigns",
    impact: "high",
    effort: "medium",
    roi: 450,
    implementation: [
      "Collect behavioral data",
      "Set up AI segmentation",
      "Create dynamic content",
      "Test and optimize",
    ],
    expert: "Ann Handley",
    trend: "Hyper-Personalization",
  },
]

export function AIJobManager() {
  const [jobs, setJobs] = useState<AIJob[]>(mockJobs)
  const [selectedJob, setSelectedJob] = useState<AIJob | null>(null)
  const [showCreateJob, setShowCreateJob] = useState(false)
  const [newJob, setNewJob] = useState({
    title: "",
    description: "",
    type: "content" as AIJob["type"],
    priority: "medium" as AIJob["priority"],
  })

  const handleCreateJob = () => {
    const job: AIJob = {
      id: Date.now().toString(),
      ...newJob,
      status: "pending",
      progress: 0,
      estimatedTime: "Calculating...",
      aiSuggestions: [],
      customizations: {},
      createdAt: new Date().toISOString(),
    }
    setJobs([job, ...jobs])
    setNewJob({ title: "", description: "", type: "content", priority: "medium" })
    setShowCreateJob(false)
  }

  const handleImplementSuggestion = (suggestion: AISuggestion) => {
    const job: AIJob = {
      id: Date.now().toString(),
      title: `AI Implementation: ${suggestion.title}`,
      description: suggestion.description,
      type: "automation",
      status: "running",
      priority: suggestion.impact === "high" ? "high" : "medium",
      progress: 15,
      estimatedTime: `${suggestion.effort === "low" ? "30" : suggestion.effort === "medium" ? "60" : "120"} minutes`,
      aiSuggestions: suggestion.implementation,
      customizations: { expert: suggestion.expert, trend: suggestion.trend, roi: suggestion.roi },
      createdAt: new Date().toISOString(),
    }
    setJobs([job, ...jobs])
  }

  const getStatusColor = (status: AIJob["status"]) => {
    switch (status) {
      case "completed":
        return "text-green-500"
      case "running":
        return "text-blue-500"
      case "failed":
        return "text-red-500"
      default:
        return "text-yellow-500"
    }
  }

  const getStatusIcon = (status: AIJob["status"]) => {
    switch (status) {
      case "completed":
        return CheckCircle
      case "running":
        return Play
      case "failed":
        return AlertCircle
      default:
        return Clock
    }
  }

  const getPriorityColor = (priority: AIJob["priority"]) => {
    switch (priority) {
      case "urgent":
        return "bg-red-500"
      case "high":
        return "bg-orange-500"
      case "medium":
        return "bg-blue-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-primary via-purple-500 to-orange-500 bg-clip-text text-transparent">
            AI Job Manager
          </h2>
          <p className="text-muted-foreground mt-1">Automate and customize your digital marketing tasks with AI</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="gap-1 bg-gradient-to-r from-primary/10 to-purple-500/10">
            <Brain className="h-3 w-3" />
            Premium Feature
          </Badge>
          <Button onClick={() => setShowCreateJob(true)} className="bg-gradient-to-r from-primary to-purple-500">
            <Plus className="h-4 w-4 mr-2" />
            New Job
          </Button>
        </div>
      </div>

      <Tabs defaultValue="jobs" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="jobs">Active Jobs</TabsTrigger>
          <TabsTrigger value="suggestions">AI Suggestions</TabsTrigger>
          <TabsTrigger value="templates">Job Templates</TabsTrigger>
        </TabsList>

        <TabsContent value="jobs" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              {jobs.map((job) => {
                const StatusIcon = getStatusIcon(job.status)
                return (
                  <Card
                    key={job.id}
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => setSelectedJob(job)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg">{job.title}</CardTitle>
                          <CardDescription className="mt-1">{job.description}</CardDescription>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${getPriorityColor(job.priority)}`} />
                          <StatusIcon className={`h-4 w-4 ${getStatusColor(job.status)}`} />
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Progress</span>
                          <span className="font-medium">{job.progress}%</span>
                        </div>
                        <Progress value={job.progress} className="h-2" />
                        <div className="flex items-center justify-between text-sm">
                          <Badge variant="outline" className="text-xs">
                            {job.type.toUpperCase()}
                          </Badge>
                          <span className="text-muted-foreground">{job.estimatedTime}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            <div className="space-y-4">
              {selectedJob && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="h-4 w-4" />
                      Job Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">AI Suggestions</h4>
                      <div className="space-y-2">
                        {selectedJob.aiSuggestions.map((suggestion, index) => (
                          <div key={index} className="flex items-center gap-2 text-sm">
                            <Lightbulb className="h-3 w-3 text-yellow-500" />
                            <span>{suggestion}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">Customizations</h4>
                      <div className="space-y-2 text-sm">
                        {Object.entries(selectedJob.customizations).map(([key, value]) => (
                          <div key={key} className="flex justify-between">
                            <span className="text-muted-foreground capitalize">{key}:</span>
                            <span>{Array.isArray(value) ? value.join(", ") : String(value)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                        <Pause className="h-3 w-3 mr-1" />
                        Pause
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                        <Settings className="h-3 w-3 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-4 w-4" />
                    Job Statistics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-primary">
                        {jobs.filter((j) => j.status === "completed").length}
                      </div>
                      <div className="text-xs text-muted-foreground">Completed</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-blue-500">
                        {jobs.filter((j) => j.status === "running").length}
                      </div>
                      <div className="text-xs text-muted-foreground">Running</div>
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-green-500">94%</div>
                    <div className="text-xs text-muted-foreground">Success Rate</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="suggestions" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
            {aiSuggestions.map((suggestion) => (
              <Card key={suggestion.id} className="relative overflow-hidden">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <Badge variant="outline" className="text-xs mb-2">
                      {suggestion.category}
                    </Badge>
                    <div className="flex items-center gap-1">
                      <TrendingUp className="h-3 w-3 text-green-500" />
                      <span className="text-xs text-green-500">{suggestion.roi}% ROI</span>
                    </div>
                  </div>
                  <CardTitle className="text-lg">{suggestion.title}</CardTitle>
                  <CardDescription>{suggestion.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <Target
                        className={`h-3 w-3 ${suggestion.impact === "high" ? "text-red-500" : suggestion.impact === "medium" ? "text-yellow-500" : "text-green-500"}`}
                      />
                      <span>Impact: {suggestion.impact}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock
                        className={`h-3 w-3 ${suggestion.effort === "high" ? "text-red-500" : suggestion.effort === "medium" ? "text-yellow-500" : "text-green-500"}`}
                      />
                      <span>Effort: {suggestion.effort}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-xs text-muted-foreground">Expert: {suggestion.expert}</div>
                    <div className="text-xs text-muted-foreground">Trend: {suggestion.trend}</div>
                  </div>
                  <Button
                    onClick={() => handleImplementSuggestion(suggestion)}
                    className="w-full bg-gradient-to-r from-primary to-purple-500"
                  >
                    <Rocket className="h-4 w-4 mr-2" />
                    Implement with AI
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              {
                title: "SEO Content Audit",
                description: "Comprehensive SEO analysis and optimization",
                type: "seo",
                icon: Target,
              },
              {
                title: "Social Media Blitz",
                description: "30-day social media content generation",
                type: "social",
                icon: Users,
              },
              {
                title: "Email Nurture Sequence",
                description: "Automated email campaign series",
                type: "email",
                icon: Calendar,
              },
              {
                title: "Competitor Analysis",
                description: "AI-powered competitive intelligence",
                type: "analytics",
                icon: BarChart3,
              },
              {
                title: "Content Repurposing",
                description: "Transform content across multiple formats",
                type: "content",
                icon: Wand2,
              },
              {
                title: "Lead Scoring Automation",
                description: "AI-driven lead qualification system",
                type: "automation",
                icon: Brain,
              },
            ].map((template, index) => {
              const Icon = template.icon
              return (
                <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-gradient-to-r from-primary/10 to-purple-500/10">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-base">{template.title}</CardTitle>
                        <Badge variant="outline" className="text-xs mt-1">
                          {template.type.toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4">{template.description}</p>
                    <Button variant="outline" className="w-full bg-transparent">
                      <Plus className="h-4 w-4 mr-2" />
                      Use Template
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>
      </Tabs>

      {showCreateJob && (
        <Card className="fixed inset-4 z-50 max-w-md mx-auto my-auto bg-background border shadow-lg">
          <CardHeader>
            <CardTitle>Create New AI Job</CardTitle>
            <CardDescription>Set up a new automated marketing task</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              placeholder="Job title"
              value={newJob.title}
              onChange={(e) => setNewJob({ ...newJob, title: e.target.value })}
            />
            <Textarea
              placeholder="Job description"
              value={newJob.description}
              onChange={(e) => setNewJob({ ...newJob, description: e.target.value })}
            />
            <Select value={newJob.type} onValueChange={(value: AIJob["type"]) => setNewJob({ ...newJob, type: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="content">Content</SelectItem>
                <SelectItem value="seo">SEO</SelectItem>
                <SelectItem value="social">Social Media</SelectItem>
                <SelectItem value="email">Email</SelectItem>
                <SelectItem value="analytics">Analytics</SelectItem>
                <SelectItem value="automation">Automation</SelectItem>
              </SelectContent>
            </Select>
            <Select
              value={newJob.priority}
              onValueChange={(value: AIJob["priority"]) => setNewJob({ ...newJob, priority: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low Priority</SelectItem>
                <SelectItem value="medium">Medium Priority</SelectItem>
                <SelectItem value="high">High Priority</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex gap-2">
              <Button onClick={handleCreateJob} className="flex-1">
                Create Job
              </Button>
              <Button variant="outline" onClick={() => setShowCreateJob(false)} className="flex-1">
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
