"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Brain, TrendingUp, Users, Shield, KeyRound } from "lucide-react"

interface LoginFormProps {
  onLogin: (user: {
    id: string
    email: string
    name: string
    role: "basic" | "premium" | "super"
  }) => void
}

export function LoginForm({ onLogin }: LoginFormProps) {
  const [email, setEmail] = useState("")
  const [name, setName] = useState("")
  const [role, setRole] = useState<"basic" | "premium" | "super">("basic")
  const [showOTP, setShowOTP] = useState(false)
  const [otp, setOTP] = useState("")
  const [isVerifying, setIsVerifying] = useState(false)

  const dummyUsers = {
    basic: { email: "basic@demo.com", name: "Basic User" },
    premium: { email: "premium@demo.com", name: "Premium User" },
    super: { email: "super@demo.com", name: "Super Admin" },
  }

  const fillDummyData = (userType: "basic" | "premium" | "super") => {
    setEmail(dummyUsers[userType].email)
    setName(dummyUsers[userType].name)
    setRole(userType)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email && name && !showOTP) {
      if (role === "premium" || role === "super") {
        setShowOTP(true)
        console.log(`[v0] OTP sent to ${email}: 123456`)
      } else {
        onLogin({
          id: Math.random().toString(36).substr(2, 9),
          email,
          name,
          role,
        })
      }
    }
  }

  const handleOTPVerify = (e: React.FormEvent) => {
    e.preventDefault()
    setIsVerifying(true)

    setTimeout(() => {
      if (otp === "123456") {
        onLogin({
          id: Math.random().toString(36).substr(2, 9),
          email,
          name,
          role,
        })
      } else {
        alert("Invalid OTP. Please try 123456")
      }
      setIsVerifying(false)
    }, 1000)
  }

  const OTPInput = () => (
    <div className="space-y-4">
      <div className="text-center">
        <div className="bg-primary/10 rounded-full p-3 w-fit mx-auto mb-4">
          <KeyRound className="h-6 w-6 text-primary" />
        </div>
        <h3 className="text-lg font-semibold">Verify Your Identity</h3>
        <p className="text-sm text-muted-foreground">We've sent a 6-digit code to {email}</p>
      </div>

      <form onSubmit={handleOTPVerify} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="otp">Enter OTP Code</Label>
          <Input
            id="otp"
            type="text"
            placeholder="123456"
            value={otp}
            onChange={(e) => setOTP(e.target.value)}
            maxLength={6}
            className="text-center text-lg tracking-widest"
            required
          />
          <p className="text-xs text-muted-foreground text-center">Demo code: 123456</p>
        </div>

        <div className="flex gap-2">
          <Button type="button" variant="outline" onClick={() => setShowOTP(false)} className="flex-1">
            Back
          </Button>
          <Button type="submit" disabled={isVerifying || otp.length !== 6} className="flex-1">
            {isVerifying ? "Verifying..." : "Verify & Sign In"}
          </Button>
        </div>
      </form>
    </div>
  )

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <div className="bg-gradient-to-r from-primary to-secondary rounded-full p-3">
              <Brain className="h-8 w-8 text-primary-foreground" />
            </div>
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            AI Marketing Agent
          </h1>
          <p className="text-muted-foreground mt-2">Automate your digital marketing with AI-powered insights</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{showOTP ? "Two-Factor Authentication" : "Sign In"}</CardTitle>
            <CardDescription>
              {showOTP
                ? "Complete your secure login with OTP verification"
                : "Enter your details to access your marketing dashboard"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {showOTP ? (
              <OTPInput />
            ) : (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Quick Demo Login</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => fillDummyData("basic")}
                      className="text-xs"
                    >
                      <Users className="h-3 w-3 mr-1" />
                      Basic
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => fillDummyData("premium")}
                      className="text-xs"
                    >
                      <TrendingUp className="h-3 w-3 mr-1" />
                      Premium
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => fillDummyData("super")}
                      className="text-xs"
                    >
                      <Brain className="h-3 w-3 mr-1" />
                      Super
                    </Button>
                  </div>
                  <div className="text-xs text-muted-foreground text-center">Click to auto-fill demo credentials</div>
                </div>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background px-2 text-muted-foreground">Or enter manually</span>
                  </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="Enter your name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="role">Account Type</Label>
                    <Select value={role} onValueChange={(value: "basic" | "premium" | "super") => setRole(value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your plan" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic">
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4" />
                            <div>
                              <div>Basic Plan</div>
                              <div className="text-xs text-muted-foreground">Standard features</div>
                            </div>
                          </div>
                        </SelectItem>
                        <SelectItem value="premium">
                          <div className="flex items-center gap-2">
                            <TrendingUp className="h-4 w-4" />
                            <div>
                              <div className="flex items-center gap-1">
                                Premium Plan
                                <Shield className="h-3 w-3 text-orange-500" />
                              </div>
                              <div className="text-xs text-muted-foreground">Advanced features + 2FA</div>
                            </div>
                          </div>
                        </SelectItem>
                        <SelectItem value="super">
                          <div className="flex items-center gap-2">
                            <Brain className="h-4 w-4" />
                            <div>
                              <div className="flex items-center gap-1">
                                Super User
                                <Shield className="h-3 w-3 text-red-500" />
                              </div>
                              <div className="text-xs text-muted-foreground">Full access + Admin + 2FA</div>
                            </div>
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button type="submit" className="w-full">
                    {role === "basic" ? "Sign In to Dashboard" : "Continue with 2FA"}
                  </Button>
                </form>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="text-center text-sm text-muted-foreground">
          {showOTP ? (
            "Secure authentication powered by AI Marketing Agent"
          ) : (
            <div className="space-y-1">
              <div>Demo mode - Premium/Super users require OTP verification</div>
              <div className="text-xs">
                <strong>Demo Accounts:</strong> basic@demo.com | premium@demo.com | super@demo.com
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
