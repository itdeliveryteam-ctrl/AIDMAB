export type UserRole = "basic" | "premium" | "super"

export interface FeatureAccess {
  canAccess: boolean
  requiresUpgrade: boolean
  upgradeMessage?: string
  planRequired?: UserRole
}

export const FEATURE_LIMITS = {
  basic: {
    aiContentGeneration: { limit: 5, period: "day" },
    socialMediaPosts: { limit: 10, period: "month" },
    seoKeywords: { limit: 50, period: "month" },
    crmContacts: { limit: 100, period: "total" },
    teamMembers: { limit: 1, period: "total" },
    analyticsHistory: { limit: 30, period: "days" },
  },
  premium: {
    aiContentGeneration: { limit: 50, period: "day" },
    socialMediaPosts: { limit: 100, period: "month" },
    seoKeywords: { limit: 500, period: "month" },
    crmContacts: { limit: 1000, period: "total" },
    teamMembers: { limit: 5, period: "total" },
    analyticsHistory: { limit: 365, period: "days" },
  },
  super: {
    aiContentGeneration: { limit: -1, period: "unlimited" },
    socialMediaPosts: { limit: -1, period: "unlimited" },
    seoKeywords: { limit: -1, period: "unlimited" },
    crmContacts: { limit: -1, period: "unlimited" },
    teamMembers: { limit: -1, period: "unlimited" },
    analyticsHistory: { limit: -1, period: "unlimited" },
  },
}

export const FEATURE_ACCESS = {
  // AI Content Generation
  aiContentGeneration: {
    basic: true,
    premium: true,
    super: true,
  },
  aiContentTemplates: {
    basic: false,
    premium: true,
    super: true,
  },
  aiContentBulkGeneration: {
    basic: false,
    premium: true,
    super: true,
  },
  aiRecommendations: {
    basic: false,
    premium: true,
    super: true,
  },
  aiJobManager: {
    basic: false,
    premium: true,
    super: true,
  },

  // SEO/SEM Analytics
  seoBasicAnalytics: {
    basic: true,
    premium: true,
    super: true,
  },
  seoAdvancedAnalytics: {
    basic: false,
    premium: true,
    super: true,
  },
  competitorAnalysis: {
    basic: false,
    premium: true,
    super: true,
  },
  keywordResearch: {
    basic: false,
    premium: true,
    super: true,
  },

  // Social Media Management
  socialMediaBasic: {
    basic: true,
    premium: true,
    super: true,
  },
  socialMediaScheduling: {
    basic: false,
    premium: true,
    super: true,
  },
  socialMediaAnalytics: {
    basic: false,
    premium: true,
    super: true,
  },
  multiPlatformPosting: {
    basic: false,
    premium: true,
    super: true,
  },

  // Content Calendar & Tasks
  basicCalendar: {
    basic: true,
    premium: true,
    super: true,
  },
  advancedCalendar: {
    basic: false,
    premium: true,
    super: true,
  },
  teamCollaboration: {
    basic: false,
    premium: true,
    super: true,
  },
  workflowAutomation: {
    basic: false,
    premium: false,
    super: true,
  },

  // CRM Integration
  basicCrm: {
    basic: false,
    premium: true,
    super: true,
  },
  advancedCrm: {
    basic: false,
    premium: false,
    super: true,
  },
  crmAutomation: {
    basic: false,
    premium: false,
    super: true,
  },

  // Admin Features
  adminPanel: {
    basic: false,
    premium: false,
    super: true,
  },
  userManagement: {
    basic: false,
    premium: false,
    super: true,
  },
  systemSettings: {
    basic: false,
    premium: false,
    super: true,
  },
}

export function useFeatureAccess(userRole: UserRole) {
  const checkFeatureAccess = (featureName: keyof typeof FEATURE_ACCESS): FeatureAccess => {
    const feature = FEATURE_ACCESS[featureName]
    const canAccess = feature[userRole]

    if (canAccess) {
      return { canAccess: true, requiresUpgrade: false }
    }

    // Determine required plan
    let planRequired: UserRole = "premium"
    if (feature.super && !feature.premium) {
      planRequired = "super"
    }

    const upgradeMessages = {
      premium: "Upgrade to Premium to unlock this feature",
      super: "Upgrade to Super User for full access",
    }

    return {
      canAccess: false,
      requiresUpgrade: true,
      upgradeMessage: upgradeMessages[planRequired],
      planRequired,
    }
  }

  const getFeatureLimit = (featureName: keyof (typeof FEATURE_LIMITS)[UserRole]) => {
    return FEATURE_LIMITS[userRole][featureName]
  }

  return {
    checkFeatureAccess,
    getFeatureLimit,
    userRole,
    isPremium: userRole === "premium" || userRole === "super",
    isSuper: userRole === "super",
  }
}
