import { Navigation } from "@/components/marketing/navigation"
import { Footer } from "@/components/marketing/footer"
import { BookOpen, Video, FileText, Download, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function ResourcesPage() {
  const resources = [
    {
      category: "Getting Started",
      items: [
        { title: "Quick Start Guide", type: "guide", icon: BookOpen, description: "Get up and running in 5 minutes" },
        {
          title: "Platform Overview",
          type: "video",
          icon: Video,
          description: "Complete walkthrough of AIDMAB features",
        },
        {
          title: "Best Practices",
          type: "pdf",
          icon: FileText,
          description: "Marketing automation best practices guide",
        },
      ],
    },
    {
      category: "Advanced Features",
      items: [
        {
          title: "AI Content Generation",
          type: "guide",
          icon: BookOpen,
          description: "Master AI-powered content creation",
        },
        {
          title: "SEO Optimization",
          type: "video",
          icon: Video,
          description: "Advanced SEO strategies and automation",
        },
        { title: "CRM Integration", type: "pdf", icon: FileText, description: "Connect and sync with your CRM system" },
      ],
    },
    {
      category: "Templates & Tools",
      items: [
        { title: "Content Templates", type: "download", icon: Download, description: "Ready-to-use content templates" },
        { title: "Campaign Blueprints", type: "download", icon: Download, description: "Proven campaign structures" },
        { title: "ROI Calculator", type: "tool", icon: ExternalLink, description: "Calculate your marketing ROI" },
      ],
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent mb-6">
            Resources & Learning
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Everything you need to master AI-powered marketing automation. From quick start guides to advanced
            strategies, we've got you covered.
          </p>
        </div>
      </section>

      {/* Resources Grid */}
      <section className="pb-20 px-4">
        <div className="max-w-6xl mx-auto">
          {resources.map((category, categoryIndex) => (
            <div key={categoryIndex} className="mb-16">
              <h2 className="text-2xl font-bold mb-8">{category.category}</h2>
              <div className="grid md:grid-cols-3 gap-6">
                {category.items.map((item, itemIndex) => (
                  <Card key={itemIndex} className="hover:shadow-lg transition-shadow cursor-pointer group">
                    <CardHeader>
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                          <item.icon className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <CardTitle className="text-lg">{item.title}</CardTitle>
                          <div className="text-xs text-muted-foreground uppercase tracking-wide">{item.type}</div>
                        </div>
                      </div>
                      <CardDescription>{item.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button
                        variant="outline"
                        className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors bg-transparent"
                      >
                        {item.type === "download"
                          ? "Download"
                          : item.type === "video"
                            ? "Watch"
                            : item.type === "tool"
                              ? "Open Tool"
                              : "Read Guide"}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Help Section */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Need More Help?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Our support team is here to help you succeed with AIDMAB.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gradient-to-r from-primary to-secondary hover:opacity-90">
              Contact Support
            </Button>
            <Button size="lg" variant="outline">
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
