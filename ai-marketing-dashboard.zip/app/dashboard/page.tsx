"use client"

import { useState } from "react"
import { LoginForm } from "@/components/auth/login-form"
import { Dashboard } from "@/components/dashboard/dashboard"

export default function DashboardPage() {
  const [user, setUser] = useState<{ email: string; role: "basic" | "premium" | "super" } | null>(null)

  return (
    <div className="min-h-screen bg-background">
      {!user ? <LoginForm onLogin={setUser} /> : <Dashboard user={user} />}
    </div>
  )
}
